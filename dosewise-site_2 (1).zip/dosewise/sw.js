// Offline support: cache the app shell (HTML, CSS, JS, fonts, icon) so DoseWise opens without a connection.
// Photo reading (Tesseract.js from jsDelivr) is the only external download and is not cached here.
const CACHE = 'dosewise-v4';
const SHELL = [
  './', './index.html', './manifest.json', './icon.svg',
  './css/app.css', './js/content.js', './js/art.js', './js/app.js',
  './fonts/fraunces.woff2', './fonts/manrope.woff2', './fonts/figtree.woff2', './fonts/newsreader.woff2',
  './fonts/source-sans-3.woff2', './fonts/bricolage-grotesque.woff2', './fonts/nunito.woff2', './fonts/outfit.woff2', './fonts/inter.woff2'
];
self.addEventListener('install', e => { e.waitUntil(caches.open(CACHE).then(c => c.addAll(SHELL))); self.skipWaiting(); });
self.addEventListener('activate', e => { e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== CACHE).map(k => caches.delete(k))))); self.clients.claim(); });
self.addEventListener('fetch', e => {
  const url = new URL(e.request.url);
  if (e.request.method !== 'GET' || url.origin !== location.origin) return; // OCR engine: straight to network
  // Network first so updates arrive; fall back to the cache when offline.
  e.respondWith(fetch(e.request).then(r => { if (r.ok) { const copy = r.clone(); caches.open(CACHE).then(c => c.put(e.request, copy)); } return r; })
    .catch(() => caches.match(e.request, { ignoreSearch: true }).then(m => m || (e.request.mode === 'navigate' ? caches.match('./index.html') : undefined))));
});

# DoseWise: standalone website

A calm, installable web app for the first weeks on a new medication: daily check-ins, a routine that fits your day, a week-by-week guide, and a support circle that works by text message. Plain HTML, CSS and JavaScript. No accounts, server, build step or AI service.

## Put it online (about 2 minutes)
**Option A: Netlify Drop (easiest)**
1. Go to https://app.netlify.com/drop
2. Drag this whole folder onto the page.
3. You get a live `https://….netlify.app` link. Open it on any phone.

**Option B: GitHub Pages**
1. Create a repo and upload these files (keep the folders).
2. Settings → Pages → Deploy from branch → `main` / root.
3. Your site will be at `https://<you>.github.io/<repo>/`.

Opening `index.html` straight from a laptop also works. Hosting it gives you a real link to text people, plus "Add to Home Screen", offline support and camera upload on phones.

## Files
```
index.html        App shell (top bar, navigation, screen, overlays)
css/app.css       Design system: tokens, five themes, components, layout, motion
js/content.js     Medication content (unchanged from the prototype) and option lists
js/art.js         SVG icon sprite, illustrations, mood/sleep/energy characters
js/app.js         State, link sharing, logic, rendering and actions
fonts/            Nine variable fonts, bundled locally (SIL Open Font License, see fonts/licenses/)
sw.js             Offline cache for the app shell
manifest.json     Install metadata
icon.svg          App icon
```

## How it works
- **Data** stays on each person's own device, in browser storage (`dosewise_site_v3`). Nothing is uploaded. Data saved by the previous version keeps working, and old theme choices map to the new themes (Forest → Botanical, Plum → Plum Editorial, Sand → Sandstone, Night → Midnight).
- **Themes**: Botanical, Coastal, Plum Editorial, Sandstone and Midnight, chosen in Settings → Appearance. Each changes type, surfaces, borders, shadows and illustration shapes, not just colour.
- **Offline**: the app shell, fonts and icons are cached by the service worker, so the app opens without a connection. Nothing decorative is loaded from the network.
- **Photo reading** uses Tesseract.js, an open-source OCR engine that runs on the device. It is the only external download: the first scan fetches the reader (about 10 MB) from jsDelivr, so it needs a connection that one time. The app then pulls out the drug, strength (mg), directions, quantity, refills, and pharmacy or prescriber.
- **Circle** works by text message, with no server: every update is a link.
  - Maya taps "Send an invite", and a text goes out with a link.
  - Jordan opens the link, joins, and texts back a "join" link.
  - Maya taps that link, and Jordan appears in her circle.
  - Status updates, asks, "thinking of you" and plans travel the same way.
- **Check-in questions use circle data.** Example: "Jordan was thinking of you. Did that help?"
- **Report** has a phone script, "Copy full summary" and a print layout.

## Accessibility and motion
- Works with touch, mouse and keyboard. Mood and other single-choice options are radio groups (arrow keys move the selection); no swipe gestures are needed.
- Dialogs trap focus, close with Esc and return focus to where you were.
- Reduced-motion settings are honoured everywhere, including the synapse animation, which becomes a still picture. The urgent support screen always appears instantly.
- Text and status colours in every theme meet WCAG AA contrast.

## Demo tips
- Use two devices (a laptop and a phone) to show the circle loop live.
- Settings → Demo tools → "Add 2 weeks of sample check-ins" fills in patterns for the pitch. They're labeled as sample data throughout.
- Medication content is a prototype. A pharmacist should review it before real use.

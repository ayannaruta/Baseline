'use strict';
/* =====================================================================
   DoseWise visual language
   - Icons: one 24px stroke family (1.75 stroke, round caps + joins),
     inlined once as an SVG sprite so they work offline.
   - Illustrations: flat two-tone shapes on the theme's backdrop shape,
     fine ink details. Colours come from --ill-* tokens per theme.
   - Characters (mood, sleep, energy): same palette and line weight.
   ===================================================================== */
const ICONS={
 // navigation
 today:'<circle cx="12" cy="12" r="4"/><path d="M12 3v1.8M12 19.2V21M3 12h1.8M19.2 12H21M5.6 5.6l1.3 1.3M17.1 17.1l1.3 1.3M5.6 18.4l1.3-1.3M17.1 6.9l1.3-1.3"/>',
 journey:'<path d="M4 18.5c3 0 3.5-5 8-5s5-5 8-5"/><circle cx="4" cy="18.5" r="1.6"/><path d="M18 3.5v5M18 3.5h3.2l-.9 1.4.9 1.4H18"/>',
 routine:'<rect x="3" y="8.5" width="18" height="7" rx="3.5" transform="rotate(-40 12 12)"/><path d="M9.6 9.1l4.8 5.8"/>',
 circle:'<circle cx="9" cy="8.5" r="3.2"/><path d="M3 19.5c.6-3.3 3-5 6-5s5.4 1.7 6 5"/><circle cx="16.8" cy="9.6" r="2.5"/><path d="M16.4 14.6c2.6-.2 4.3 1.5 4.7 4.4"/>',
 report:'<rect x="5" y="4.5" width="14" height="16.5" rx="2.5"/><path d="M9 4.5V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v.5a1 1 0 0 1-1 1h-4a1 1 0 0 1-1-1z"/><path d="M8.8 11h6.4M8.8 14.5h6.4M8.8 18h3.6"/>',
 settings:'<path d="M4 7h8.5M17.5 7H20M4 17h2.5M11.5 17H20"/><circle cx="15" cy="7" r="2.5"/><circle cx="9" cy="17" r="2.5"/>',
 // general
 'chevron-left':'<path d="M14.5 18l-6-6 6-6"/>','chevron-right':'<path d="M9.5 6l6 6-6 6"/>','chevron-down':'<path d="M6 9.5l6 6 6-6"/>',
 'arrow-right':'<path d="M5 12h14M13.5 6.5 19 12l-5.5 5.5"/>',
 x:'<path d="M6.5 6.5l11 11M17.5 6.5l-11 11"/>',plus:'<path d="M12 5v14M5 12h14"/>',minus:'<path d="M5 12h14"/>',
 check:'<path d="M5 12.5l4.5 4.5L19 7.5"/>',
 'check-circle':'<circle cx="12" cy="12" r="8.75"/><path d="M8.2 12.3l2.6 2.6 5-5.2"/>',
 'circle-dashed':'<circle cx="12" cy="12" r="8.75" stroke-dasharray="2.6 3"/>',
 'pin':'<circle cx="12" cy="12" r="8.75"/><circle cx="12" cy="12" r="3.2" fill="currentColor" stroke="none"/>',
 alert:'<path d="M10.3 4.4 3 17.1A2 2 0 0 0 4.7 20h14.6a2 2 0 0 0 1.7-2.9L13.7 4.4a2 2 0 0 0-3.4 0z"/><path d="M12 9.5v4"/><circle cx="12" cy="16.6" r=".4" fill="currentColor"/>',
 info:'<circle cx="12" cy="12" r="8.75"/><path d="M12 11v5"/><circle cx="12" cy="7.9" r=".4" fill="currentColor"/>',
 octagon:'<path d="M8.3 3.2h7.4l5.1 5.1v7.4l-5.1 5.1H8.3l-5.1-5.1V8.3z"/><path d="M12 8v4.8"/><circle cx="12" cy="15.9" r=".4" fill="currentColor"/>',
 ban:'<circle cx="12" cy="12" r="8.75"/><path d="M5.8 5.8l12.4 12.4"/>',
 phone:'<path d="M5.4 3.8h3l1.6 4.1-2.1 1.3a11.5 11.5 0 0 0 5 5l1.3-2.1 4.1 1.6v3a2 2 0 0 1-2.1 2A15.6 15.6 0 0 1 3.4 5.9a2 2 0 0 1 2-2.1z"/>',
 message:'<path d="M5 4.8h14a2 2 0 0 1 2 2v8.4a2 2 0 0 1-2 2h-7.6L7 20.6v-3.4H5a2 2 0 0 1-2-2V6.8a2 2 0 0 1 2-2z"/>',
 send:'<path d="M20.5 3.5 10.6 13.4"/><path d="M20.5 3.5 14.2 20.6l-3.6-7.2-7.1-3.6z"/>',
 copy:'<rect x="8.5" y="8.5" width="12" height="12" rx="2"/><path d="M15.5 8.5V5.5a2 2 0 0 0-2-2h-8a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h3"/>',
 lock:'<rect x="4.5" y="10.5" width="15" height="10" rx="2.5"/><path d="M8 10.5V7.8a4 4 0 0 1 8 0v2.7"/><path d="M12 14.5v2"/>',
 camera:'<path d="M4.5 7.5h3l1.6-2.5h5.8l1.6 2.5h3a1.5 1.5 0 0 1 1.5 1.5v9a1.5 1.5 0 0 1-1.5 1.5h-15A1.5 1.5 0 0 1 3 18V9a1.5 1.5 0 0 1 1.5-1.5z"/><circle cx="12" cy="13" r="3.4"/>',
 upload:'<path d="M12 15V4.5M7.5 9 12 4.5 16.5 9M4 15v3a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-3"/>',
 sparkle:'<path d="M11 3.5l1.7 4.8 4.8 1.7-4.8 1.7L11 16.5l-1.7-4.8L4.5 10l4.8-1.7z"/><path d="M18 15v5M15.5 17.5h5"/>',
 heart:'<path d="M12 19.8s-7.6-4.5-7.6-10.1A4.2 4.2 0 0 1 12 7.3a4.2 4.2 0 0 1 7.6 2.4c0 5.6-7.6 10.1-7.6 10.1z"/>',
 calendar:'<rect x="3.8" y="5.3" width="16.4" height="14.9" rx="2.5"/><path d="M3.8 10h16.4M8.3 3.3v4M15.7 3.3v4"/><circle cx="12" cy="14.8" r=".5" fill="currentColor"/>',
 clock:'<circle cx="12" cy="12" r="8.75"/><path d="M12 7.5V12l3 2"/>',
 sun:'<circle cx="12" cy="12" r="3.8"/><path d="M12 3v1.8M12 19.2V21M3 12h1.8M19.2 12H21M5.6 5.6l1.3 1.3M17.1 17.1l1.3 1.3M5.6 18.4l1.3-1.3M17.1 6.9l1.3-1.3"/>',
 moon:'<path d="M19.8 14.6A8.2 8.2 0 0 1 9.4 4.2a8.2 8.2 0 1 0 10.4 10.4z"/>',
 'moon-star':'<path d="M18.6 15.4A7.6 7.6 0 0 1 8.6 5.4a7.6 7.6 0 1 0 10 10z"/><path d="M17 3v4M15 5h4"/>',
 utensils:'<path d="M6.5 3v6.2a2.3 2.3 0 0 0 4.6 0V3M8.8 3v18"/><path d="M17.5 21V3c-2 1.2-3 3.8-3 7.3V13h3"/>',
 'glass-off':'<path d="M8 3.5h8l-.5 4.8a3.5 3.5 0 0 1-7 0z"/><path d="M12 12v8M8.5 20h7"/><path d="M4 4l16 16"/>',
 pill:'<rect x="3" y="8.5" width="18" height="7" rx="3.5" transform="rotate(-40 12 12)"/><path d="M9.6 9.1l4.8 5.8"/>',
 'pill-off':'<path d="M13.1 6.2l1.6-1.4a3.5 3.5 0 0 1 4.5 5.4l-1.7 1.4M10.9 17.8l-1.6 1.4a3.5 3.5 0 0 1-4.5-5.4l3.3-2.7"/><path d="M4 4l16 16"/>',
 bottle:'<rect x="7.5" y="3" width="9" height="3.5" rx="1"/><path d="M6.5 8.5a2 2 0 0 1 2-2h7a2 2 0 0 1 2 2V19a2 2 0 0 1-2 2h-7a2 2 0 0 1-2-2z"/><path d="M6.5 11.5h11v5h-11"/>',
 leaf:'<path d="M5 19.5c0-8.5 5.5-14.5 15-14.5 0 9.8-6 15.5-14 15.5"/><path d="M5 19.5l7.5-7.5"/>',
 sprout:'<path d="M12 21v-8.5"/><path d="M12 12.5C12 8.6 9.3 6.5 5 6.5c0 3.9 2.7 6 7 6z"/><path d="M12 10.5c0-3.6 2.6-6 7-6 0 3.9-2.8 6-7 6z"/>',
 thermometer:'<path d="M10 14.3V5a2 2 0 0 1 4 0v9.3a4 4 0 1 1-4 0z"/><path d="M12 9.5v7"/>',
 eye:'<path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12z"/><circle cx="12" cy="12" r="3"/>',
 users:'<circle cx="9" cy="8.5" r="3.2"/><path d="M3 19.5c.6-3.3 3-5 6-5s5.4 1.7 6 5"/><circle cx="16.8" cy="9.6" r="2.5"/><path d="M16.4 14.6c2.6-.2 4.3 1.5 4.7 4.4"/>',
 user:'<circle cx="12" cy="8" r="3.6"/><path d="M5 20c.8-3.8 3.6-6 7-6s6.2 2.2 7 6"/>',
 hand:'<path d="M8.5 12.5V6a1.5 1.5 0 0 1 3 0v5"/><path d="M11.5 10.5V4.5a1.5 1.5 0 0 1 3 0v6"/><path d="M14.5 10.5V6.5a1.5 1.5 0 0 1 3 0v7.5a6.5 6.5 0 0 1-6.5 6.5h-.4a5.6 5.6 0 0 1-4.7-2.6L3.7 14.6a1.5 1.5 0 0 1 2.5-1.6l2.3 2.5"/>',
 coffee:'<path d="M4 9.5h12v4.3a5 5 0 0 1-5 5H9a5 5 0 0 1-5-5z"/><path d="M16 10.5h1.3a2.6 2.6 0 0 1 0 5.2H16"/><path d="M8 3.5c-.7 1 .7 2 0 3.2M12 3.5c-.7 1 .7 2 0 3.2"/>',
 'cloud-rain':'<path d="M7.2 15.5a4 4 0 0 1-.5-8A5.5 5.5 0 0 1 17.3 8a3.8 3.8 0 0 1 .3 7.5z"/><path d="M8.5 18.5l-.9 2M12.3 18.5l-.9 2M16.1 18.5l-.9 2"/>',
 cloud:'<path d="M7.2 18a4 4 0 0 1-.5-8A5.5 5.5 0 0 1 17.3 10.5a3.8 3.8 0 0 1 .3 7.5z"/>',
 'sun-cloud':'<path d="M7.5 3v1.5M3 7.5h1.5M4.3 4.3l1 1M10.7 4.3l-1 1"/><path d="M10.8 8.7A3.6 3.6 0 0 0 4.6 10"/><path d="M8.3 20a3.6 3.6 0 0 1-.4-7.2 5 5 0 0 1 9.6.4A3.4 3.4 0 0 1 17.4 20z"/>',
 award:'<circle cx="12" cy="9" r="5.5"/><path d="M8.8 13.5 7.5 21l4.5-2.4 4.5 2.4-1.3-7.5"/>',
 flag:'<path d="M5.5 21V4M5.5 4.5h11.5l-2.2 4 2.2 4H5.5"/>',
 trend:'<path d="M4 19.5h16"/><path d="M5 15l4-4.2 3.2 3.2 6.3-6.5"/><path d="M15 7.5h3.5V11"/>',
 flask:'<path d="M9 3.5h6M10 3.5v5.8L5 17.8A2.1 2.1 0 0 0 6.8 21h10.4a2.1 2.1 0 0 0 1.8-3.2l-5-8.5V3.5"/><path d="M7.3 14.5h9.4"/>',
 mail:'<rect x="3.5" y="5.5" width="17" height="13" rx="2.5"/><path d="M4.5 7.5l7.5 5.6 7.5-5.6"/>',
 printer:'<path d="M7 9V3.5h10V9"/><rect x="3.5" y="9" width="17" height="7.5" rx="2"/><path d="M7 14h10v6.5H7z"/>',
 pause:'<rect x="6.5" y="5" width="3.5" height="14" rx="1"/><rect x="14" y="5" width="3.5" height="14" rx="1"/>',
 trash:'<path d="M4.5 6.5h15M9.5 6.5V4.5a1 1 0 0 1 1-1h3a1 1 0 0 1 1 1v2M6.5 6.5l.8 12.2a2 2 0 0 0 2 1.8h5.4a2 2 0 0 0 2-1.8l.8-12.2"/>',
 palette:'<path d="M12 3.5a8.5 8.5 0 1 0 0 17c1.2 0 1.9-.9 1.9-1.9 0-.5-.2-1-.5-1.3-.3-.4-.5-.8-.5-1.3 0-1 .8-1.8 1.8-1.8h2.1a4.3 4.3 0 0 0 4.2-4.3C21 6.8 17 3.5 12 3.5z"/><circle cx="7.6" cy="11.5" r=".9" fill="currentColor"/><circle cx="10" cy="7.6" r=".9" fill="currentColor"/><circle cx="14.6" cy="7.6" r=".9" fill="currentColor"/>',
 shield:'<path d="M12 3.2 5 6v5.5c0 4.4 3 7.9 7 9.3 4-1.4 7-4.9 7-9.3V6z"/><path d="M9 12l2.2 2.2L15.3 10"/>',
 refresh:'<path d="M19.5 8.5A8 8 0 0 0 5 9M4.5 15.5A8 8 0 0 0 19 15"/><path d="M19.5 4v4.5H15M4.5 20v-4.5H9"/>',
 smile:'<circle cx="12" cy="12" r="8.75"/><path d="M8.6 14a4.4 4.4 0 0 0 6.8 0"/><circle cx="9.2" cy="9.8" r=".5" fill="currentColor"/><circle cx="14.8" cy="9.8" r=".5" fill="currentColor"/>',
 activity:'<path d="M3.5 12h3.8l2.2-5.5 4.5 11 2.2-5.5h4.3"/>',
 // symptoms + body
 queasy:'<circle cx="12" cy="12" r="8.75"/><circle cx="9" cy="9.8" r=".5" fill="currentColor"/><circle cx="15" cy="9.8" r=".5" fill="currentColor"/><path d="M7.8 15.2c.9-.9 1.9-.9 2.8 0s1.9.9 2.8 0 1.9-.9 2.8 0"/>',
 droplets:'<path d="M8 3.8S4.6 8 4.6 10.4a3.4 3.4 0 0 0 6.8 0C11.4 8 8 3.8 8 3.8z"/><path d="M16 9.5s-3.4 4.2-3.4 6.6a3.4 3.4 0 0 0 6.8 0c0-2.4-3.4-6.6-3.4-6.6z"/>',
 droplet:'<path d="M12 3.5S6.3 10 6.3 14.2a5.7 5.7 0 0 0 11.4 0C17.7 10 12 3.5 12 3.5z"/>',
 'droplet-off':'<path d="M12 3.5S6.3 10 6.3 14.2a5.7 5.7 0 0 0 11.4 0C17.7 10 12 3.5 12 3.5z"/><path d="M4 4.5l16 15"/>',
 sweat:'<path d="M7 3.8S4.6 6.8 4.6 8.5a2.4 2.4 0 0 0 4.8 0C9.4 6.8 7 3.8 7 3.8z"/><path d="M17 3.8s-2.4 3-2.4 4.7a2.4 2.4 0 0 0 4.8 0c0-1.7-2.4-4.7-2.4-4.7z"/><path d="M12 11.8s-2.4 3-2.4 4.7a2.4 2.4 0 0 0 4.8 0c0-1.7-2.4-4.7-2.4-4.7z"/>',
 zzz:'<path d="M4 9.5h5l-5 6h5M13 4h4l-4 5h4M15 14.5h5l-5 6h5"/>',
 spiral:'<path d="M12.6 12.2a1.3 1.3 0 1 1-1.6-1.6 2.9 2.9 0 0 1 3.9 2.4 4.4 4.4 0 0 1-4.6 4.5A5.9 5.9 0 0 1 4.6 11.6 7.4 7.4 0 0 1 12 4.2a8.5 8.5 0 0 1 8.5 8.3"/>',
 wave:'<path d="M3 12c1.4-2.8 2.8-2.8 4.2 0s2.8 2.8 4.2 0 2.8-2.8 4.2 0 2.8 2.8 4.2 0"/><path d="M3 6.5h2M19 17.5h2" opacity=".6"/>',
 'battery-low':'<rect x="3" y="7.5" width="15.5" height="9" rx="2.2"/><path d="M21 10.5v3"/><path d="M6.2 10.5v3"/>',
 head:'<path d="M8.5 21v-3.2a7 7 0 0 1-3.5-6A7 7 0 0 1 12 4.5a6.6 6.6 0 0 1 6.8 6.4l1.4 2.6h-1.7v2.7a1.8 1.8 0 0 1-1.8 1.8h-1.8V21"/><path d="M12.8 7.8 11 11h2.6l-1.8 3.2"/>',
 zap:'<path d="M13 3 5 13.5h6.2L10.5 21l8-10.5h-6.2z"/>',
 'plate-minus':'<circle cx="12" cy="12" r="8.75"/><circle cx="12" cy="12" r="5.2" opacity=".45"/><path d="M9.5 12h5"/>',
 'plate-plus':'<circle cx="12" cy="12" r="8.75"/><circle cx="12" cy="12" r="5.2" opacity=".45"/><path d="M9.5 12h5M12 9.5v5"/>',
 stomach:'<path d="M9 3.5v3.3a3 3 0 0 1-3 3 2.7 2.7 0 0 0-2.7 2.7v.8A7.2 7.2 0 0 0 10.5 20.5h1.7a8 8 0 0 0 8-8 4.9 4.9 0 0 0-8.8-3"/>',
 scale:'<rect x="3.8" y="3.8" width="16.4" height="16.4" rx="3.5"/><path d="M8.5 10a4.6 4.6 0 0 1 7 0"/><path d="M12 11.5l1.3-2.2"/>',
 virus:'<circle cx="12" cy="12" r="4.6"/><path d="M12 3.5v3.9M12 16.6v3.9M3.5 12h3.9M16.6 12h3.9M6 6l2.7 2.7M15.3 15.3 18 18M6 18l2.7-2.7M15.3 8.7 18 6"/>',
 flower:'<circle cx="12" cy="9" r="2"/><path d="M12 7a2.4 2.4 0 1 1 1.9 1M14 9a2.4 2.4 0 1 1-1.2 2.6M12 11a2.4 2.4 0 1 1-1.9-1M10 9a2.4 2.4 0 1 1 1.2-2.6"/><path d="M12 13.5V21M12 18c-2.2 0-3.7-1.1-4.3-3"/>',
 // hobbies + support + relations
 footprints:'<path d="M7.6 3.5c1.6 0 2.4 1.9 2.4 4.2S9.2 12 7.6 12 5.2 10 5.2 7.7s.8-4.2 2.4-4.2z"/><path d="M5.6 14.6h4v1.6a2 2 0 0 1-4 0z"/><path d="M16.4 7c1.6 0 2.4 1.9 2.4 4.2s-.8 4.3-2.4 4.3S14 13.5 14 11.2 14.8 7 16.4 7z"/><path d="M14.4 18h4v1.2a2 2 0 0 1-4 0z"/>',
 headphones:'<path d="M4 15.5V12a8 8 0 0 1 16 0v3.5"/><rect x="3.8" y="14.5" width="4.2" height="6" rx="1.6"/><rect x="16" y="14.5" width="4.2" height="6" rx="1.6"/>',
 pan:'<path d="M3 11.5h13v.9a5.1 5.1 0 0 1-5.1 5.1H8.1A5.1 5.1 0 0 1 3 12.4z"/><path d="M16 12.5h5"/><path d="M7.5 8c-.6-1 .6-1.9 0-3.2M11.5 8c-.6-1 .6-1.9 0-3.2"/>',
 book:'<path d="M12 6.6C10 5 7.4 4.5 4 4.5v13.2c3.4 0 6 .5 8 2.1 2-1.6 4.6-2.1 8-2.1V4.5c-3.4 0-6 .5-8 2.1z"/><path d="M12 6.6v13.2"/>',
 gamepad:'<path d="M7.3 8h9.4a4 4 0 0 1 4 4.4l-.5 3.7a2.4 2.4 0 0 1-4.2 1.2L14 15.2h-4l-2 2.1a2.4 2.4 0 0 1-4.2-1.2l-.5-3.7a4 4 0 0 1 4-4.4z"/><path d="M7.8 10.8v2.8M6.4 12.2h2.8"/><circle cx="15.6" cy="11.5" r=".5" fill="currentColor"/><circle cx="17.2" cy="13.1" r=".5" fill="currentColor"/>',
 pencil:'<path d="M4.5 19.5l.9-4.2L15.6 5.1a2.1 2.1 0 0 1 3 3L8.4 18.4z"/><path d="M13.6 7.1l3 3"/>',
 ball:'<circle cx="12" cy="12" r="8.75"/><path d="M3.3 12h17.4M12 3.3v17.4"/><path d="M5.8 5.8c2.8 3.3 2.8 9.1 0 12.4M18.2 5.8c-2.8 3.3-2.8 9.1 0 12.4"/>',
 tree:'<path d="M12 21v-5"/><path d="M12 16a5 5 0 0 1-4.7-6.7A3.5 3.5 0 0 1 12 4a3.5 3.5 0 0 1 4.7 5.3A5 5 0 0 1 12 16z"/>',
 balloon:'<path d="M12 15.2c-3.1 0-5.6-3.1-5.6-6.3a5.6 5.6 0 0 1 11.2 0c0 3.2-2.5 6.3-5.6 6.3z"/><path d="M11 15.2h2l-.5 1.3h-1z"/><path d="M12 16.5c0 2 1.6 2.4 1.6 4.5"/>',
 bowl:'<path d="M3.5 11h17a8.5 8.5 0 0 1-17 0z"/><path d="M8 7.5c-.6-1 .6-1.9 0-3.2M12 7.5c-.6-1 .6-1.9 0-3.2M16 7.5c-.6-1 .6-1.9 0-3.2"/>',
 sofa:'<path d="M5.5 11V8.5a2.5 2.5 0 0 1 2.5-2.5h8a2.5 2.5 0 0 1 2.5 2.5V11"/><path d="M3 13a2 2 0 0 1 4 0v1.2h10V13a2 2 0 0 1 4 0v4.3a1.2 1.2 0 0 1-1.2 1.2H4.2A1.2 1.2 0 0 1 3 17.3z"/><path d="M5.5 18.5v1.8M18.5 18.5v1.8"/>',
 home:'<path d="M4 10.8 12 4l8 6.8V19a1.5 1.5 0 0 1-1.5 1.5H15v-6H9v6H5.5A1.5 1.5 0 0 1 4 19z"/>',
 briefcase:'<rect x="3.5" y="7.5" width="17" height="12" rx="2.2"/><path d="M9 7.5V6a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v1.5M3.5 12.8h17"/>',
 anchor:'<circle cx="12" cy="5.5" r="2.2"/><path d="M12 7.7V20.5M5 13a7 7 0 0 0 14 0M8.5 11h7"/>',
 feather:'<path d="M19.5 4.5c-6.5 0-12 4.6-12 11.6v4"/><path d="M19.5 4.5c0 7.3-4.6 11.6-12 11.6M7.5 16.1h5.5M10 12.5h6"/>',
 toolbox:'<rect x="3.5" y="9" width="17" height="10.5" rx="2"/><path d="M9 9V7a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v2M3.5 13.8h17M10 13.8v2h4v-2"/>',
 car:'<path d="M4.5 16.8v-4l2-4.8a2 2 0 0 1 1.9-1.3h7.2a2 2 0 0 1 1.9 1.3l2 4.8v4a1 1 0 0 1-1 1h-13a1 1 0 0 1-1-1z"/><path d="M4.5 12.8h15M7 17.8v2M17 17.8v2"/><circle cx="8" cy="15" r=".5" fill="currentColor"/><circle cx="16" cy="15" r=".5" fill="currentColor"/>'
};
function spriteSVG(){
  return `<svg xmlns="http://www.w3.org/2000/svg" style="position:absolute;width:0;height:0;overflow:hidden" aria-hidden="true" focusable="false">${Object.keys(ICONS).map(k=>`<symbol id="i-${k}" viewBox="0 0 24 24">${ICONS[k]}</symbol>`).join('')}</svg>`;
}
/** Icon markup. Decorative by default; pass a label for meaning-bearing icons. */
function ic(name,cls,label){
  const n=ICONS[name]?name:'sparkle';
  return `<svg class="ic ${cls||''}" ${label?`role="img" aria-label="${label}"`:'aria-hidden="true"'} focusable="false"><use href="#i-${n}"/></svg>`;
}

/* ---------- Illustrations (viewBox 0 0 96 96) ---------- */
const INK='var(--ill-ink)',I1='var(--ill-1)',I2='var(--ill-2)',I3='var(--ill-3)',I4='var(--ill-4)';
const ln=(d,w,c)=>`<path d="${d}" fill="none" stroke="${c||INK}" stroke-width="${w||2.5}" stroke-linecap="round" stroke-linejoin="round"/>`;
const face=(x,y,s)=>{s=s||1;return `<circle cx="${x-4.5*s}" cy="${y}" r="${1.9*s}" fill="${INK}"/><circle cx="${x+4.5*s}" cy="${y}" r="${1.9*s}" fill="${INK}"/>${ln(`M${x-4*s} ${y+5*s}q${4*s} ${3.6*s} ${8*s} 0`,2.2*s)}`;};
const spark=(x,y,r,c)=>`<path d="M${x} ${y-r}l${r*.28} ${r*.72} ${r*.72} ${r*.28} -${r*.72} ${r*.28} -${r*.28} ${r*.72} -${r*.28} -${r*.72} -${r*.72} -${r*.28} ${r*.72} -${r*.28}z" fill="${c||I3}"/>`;
const ILL={
 wave:`${ln('M66 60c6-5 9-13 8.5-23',8,I1)}<circle cx="74.5" cy="33" r="6" fill="${I2}"/><path d="M20 84c0-16 10.5-25 24-25s24 9 24 25z" fill="${I1}"/><circle cx="44" cy="38" r="14" fill="${I2}"/>${face(44,37)}${ln('M82 22l4-3.5M84 32h5',2.5,I3)}`,
 pill:`<g transform="rotate(-38 48 48)"><rect x="18" y="36" width="60" height="25" rx="12.5" fill="${I1}"/><path d="M48 36h17.5a12.5 12.5 0 0 1 0 25H48z" fill="${I3}"/><path d="M27 44h10" stroke="${I4}" stroke-width="3" stroke-linecap="round" opacity=".55"/></g>${spark(74,22,7)}`,
 bottle:`<rect x="31" y="17" width="34" height="12" rx="3" fill="${I1}"/><rect x="27" y="29" width="42" height="52" rx="9" fill="${I3}"/><rect x="31" y="42" width="34" height="24" rx="4" fill="${I4}"/>${ln('M37 50h22M37 58h14',2.5)}`,
 rx:`<path d="M28 16h30l12 12v50a4 4 0 0 1-4 4H28a4 4 0 0 1-4-4V20a4 4 0 0 1 4-4z" fill="${I4}" stroke="${INK}" stroke-width="2"/><path d="M58 16v12h12" fill="none" stroke="${INK}" stroke-width="2" stroke-linejoin="round"/><rect x="32" y="28" width="16" height="6" rx="3" fill="${I1}"/>${ln('M32 46h28M32 54h22M32 62h16',2.5)}<g transform="rotate(-38 66 72)"><rect x="54" y="66" width="26" height="11" rx="5.5" fill="${I1}"/><path d="M67 66h7.5a5.5 5.5 0 0 1 0 11H67z" fill="${I3}"/></g>`,
 list:`<rect x="20" y="20" width="56" height="58" rx="8" fill="${I4}" stroke="${INK}" stroke-width="2"/><circle cx="32" cy="35" r="5" fill="${I1}"/>${ln('M30 35l1.6 1.6 3-3.2',1.8,I4)}${ln('M42 35h22',2.5)}<circle cx="32" cy="50" r="5" fill="none" stroke="${INK}" stroke-width="2"/>${ln('M42 50h18',2.5)}<circle cx="32" cy="65" r="5" fill="none" stroke="${INK}" stroke-width="2"/>${ln('M42 65h20',2.5)}`,
 sunmoon:`<circle cx="38" cy="42" r="15" fill="${I3}"/>${ln('M38 18v5M38 61v5M14 42h5M57 42h5M21 25l3.5 3.5M51.5 55.5 55 59M21 59l3.5-3.5',3,I3)}<path d="M76 66a15 15 0 1 1-12-24 12 12 0 0 0 12 24z" fill="${I1}"/>`,
 plate:`<circle cx="50" cy="52" r="26" fill="${I4}" stroke="${INK}" stroke-width="2"/><circle cx="50" cy="52" r="17" fill="none" stroke="${INK}" stroke-width="1.5" opacity=".35"/><circle cx="45" cy="49" r="6" fill="${I3}"/><circle cx="56" cy="56" r="5" fill="${I2}"/>${ln('M16 30v24M12 30v9a4 4 0 0 0 8 0v-9',2.5)}${ln('M84 30v26M84 30c5 4 5 12 0 15',2.5)}`,
 body:`<circle cx="48" cy="35" r="12" fill="${I1}"/><path d="M27 82c0-17 9-27 21-27s21 10 21 27z" fill="${I1}"/>${ln('M22 40c-4 6-4 14 0 20M74 40c4 6 4 14 0 20',2.5,I3)}${ln('M15 34c-6 9-6 23 0 32M81 34c6 9 6 23 0 32',2.5,I2)}`,
 heart:`<path d="M48 78C20 60 20 36 35 33c8-1.6 13 4.2 13 7.5 0-3.3 5-9.1 13-7.5 15 3 15 27-13 45z" fill="${I3}"/>${ln('M20 70c8-9 16-8 22-3M76 70c-8-9-16-8-22-3',4,I1)}`,
 star:`<path d="M48 18l8.5 18.2 20 2.4-14.8 13.6 4 19.8L48 62l-17.7 10 4-19.8L19.5 38.6l20-2.4z" fill="${I3}" stroke="${INK}" stroke-width="2" stroke-linejoin="round"/>${spark(78,24,6,I1)}<circle cx="20" cy="74" r="3.5" fill="${I2}"/>`,
 meds:`<rect x="20" y="36" width="24" height="36" rx="6" fill="${I2}"/><rect x="18" y="29" width="28" height="9" rx="3" fill="${I1}"/><circle cx="64" cy="45" r="11" fill="${I4}" stroke="${INK}" stroke-width="2"/>${ln('M57 45h14',2)}<g transform="rotate(-20 64 70)"><rect x="51" y="64" width="26" height="12" rx="6" fill="${I1}"/><path d="M64 64h7a6 6 0 0 1 0 12h-7z" fill="${I3}"/></g>`,
 people:`<circle cx="35" cy="40" r="10" fill="${I1}"/><path d="M17 78c0-14 8-22 18-22s18 8 18 22z" fill="${I1}"/><circle cx="63" cy="42" r="10" fill="${I2}"/><path d="M45 80c0-14 8-22 18-22s18 8 18 22z" fill="${I2}"/><path d="M49 31c-5-3.6-9-6.8-9-10.6a4.4 4.4 0 0 1 9-1.3 4.4 4.4 0 0 1 9 1.3c0 3.8-4 7-9 10.6z" fill="${I3}"/>`,
 check:`<circle cx="48" cy="48" r="26" fill="${I1}"/>${ln('M36 48.5l8.5 8.5 16-17',5,I4)}`,
 notyet:`<circle cx="48" cy="48" r="25" fill="${I4}" stroke="${INK}" stroke-width="2.5"/>${ln('M48 33v15l10 6.5',3.5)}`,
 food:`<path d="M22 50h52c0 15-11.6 26-26 26S22 65 22 50z" fill="${I3}"/><path d="M30 50c2-6 6-9 10-9s7 3 8 9z" fill="${I2}"/><circle cx="57" cy="46" r="5" fill="${I1}"/>${ln('M38 34c-2-3 2-6 0-10M50 34c-2-3 2-6 0-10M62 34c-2-3 2-6 0-10',2.5)}`,
 nofood:`<path d="M22 50h52c0 15-11.6 26-26 26S22 65 22 50z" fill="${I4}" stroke="${INK}" stroke-width="2.5" stroke-linejoin="round"/>${ln('M30 44h36',2.5)}<circle cx="70" cy="28" r="9" fill="${I4}" stroke="${INK}" stroke-width="2"/>${ln('M66.5 28h7',2.5)}`,
 leaf:`<path d="M26 74c0-30 20-46 48-46 0 30-19 46-48 46z" fill="${I2}"/>${ln('M26 74 60 42M42 58v-12M50 50h12',3,I1)}`,
 thermo:`<rect x="40" y="16" width="16" height="48" rx="8" fill="${I4}" stroke="${INK}" stroke-width="2.5"/><circle cx="48" cy="70" r="12" fill="${I3}" stroke="${INK}" stroke-width="2.5"/><rect x="45" y="38" width="6" height="30" rx="3" fill="${I3}"/><path d="M62 34a7 7 0 0 1 7-7 9 9 0 0 1 17 3 6 6 0 0 1-1 12H66a6 6 0 0 1-4-8z" fill="${I2}"/>`,
 talk:`<path d="M18 24h40a8 8 0 0 1 8 8v16a8 8 0 0 1-8 8H36l-11 9v-9h-7a8 8 0 0 1-8-8V32a8 8 0 0 1 8-8z" fill="${I1}"/><path d="M46 48h30a8 8 0 0 1 8 8v12a8 8 0 0 1-8 8h-3v8l-9-8H46a8 8 0 0 1-8-8V56a8 8 0 0 1 8-8z" fill="${I2}"/><circle cx="30" cy="40" r="2.6" fill="${I4}"/><circle cx="38" cy="40" r="2.6" fill="${I4}"/><circle cx="46" cy="40" r="2.6" fill="${I4}"/>`,
 alone:`<circle cx="48" cy="38" r="12" fill="${I2}"/><path d="M28 82c0-16 9-25 20-25s20 9 20 25z" fill="${I2}"/>${ln('M72 22a8 8 0 1 0 8 10 6.5 6.5 0 0 1-8-10z',2.5)}`,
 mail:`<rect x="16" y="28" width="64" height="44" rx="7" fill="${I4}" stroke="${INK}" stroke-width="2.5"/>${ln('M19 32l29 21 29-21',2.5)}<path d="M48 22c-5-3.6-9-6.8-9-10.6a4.4 4.4 0 0 1 9-1.3 4.4 4.4 0 0 1 9 1.3c0 3.8-4 7-9 10.6z" fill="${I3}"/>`,
 sprout:`<path d="M30 78h36l-4 10H34z" fill="${I3}"/><rect x="27" y="72" width="42" height="8" rx="3" fill="${I1}"/>${ln('M48 72V44',3,I1)}<path d="M48 50c0-11-8-18-20-18 0 11 8 18 20 18z" fill="${I2}"/><path d="M48 44c0-11 8-18 20-18 0 11-8 18-20 18z" fill="${I1}"/>`,
 shield:`<path d="M48 16 22 26v20c0 17 11 29 26 34 15-5 26-17 26-34V26z" fill="${I1}"/>${ln('M36 48l8 8 16-16',5,I4)}`
};
function ill(k,size,extra){ return `<span class="ill ${size||'md'} ${extra||''}" aria-hidden="true"><svg viewBox="0 0 96 96" focusable="false">${ILL[k]||ILL.star}</svg></span>`; }

/* ---------- Characters ---------- */
const MOOD=[
 {w:'Stormy',d:'Really rough'},{w:'Gray',d:'Low'},{w:'Okay',d:'Getting by'},{w:'Bright',d:'Pretty good'},{w:'Glowing',d:'Great'}];
function blob(m,label){ // m: 1..5
  const F='var(--face)', c=`var(--mood-${m})`;
  const fl=(d,w)=>`<path d="${d}" stroke="${F}" stroke-width="${w||3.2}" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`;
  const eyes=m===1?fl('M31 50l8 2.5M69 50l-8 2.5'):m===5?fl('M30 51q6-6.5 12 0M58 51q6-6.5 12 0'):`<circle cx="36" cy="51" r="4.2" fill="${F}"/><circle cx="64" cy="51" r="4.2" fill="${F}"/>`;
  const mouth=[fl('M37 72q13-10 26 0'),fl('M38 69q12-4 24 0'),fl('M39 67h22'),fl('M36 64q14 12 28 0'),`<path d="M34 62q16 20 32 0z" fill="${F}"/><path d="M41.5 70q8.5 5 17 0" fill="var(--cheek)"/>`][m-1];
  const cheeks=m>=4?`<circle cx="26.5" cy="61" r="5" fill="var(--cheek)" opacity=".5"/><circle cx="73.5" cy="61" r="5" fill="var(--cheek)" opacity=".5"/>`:'';
  const acc=[`<g fill="var(--ill-2)"><ellipse cx="50" cy="3" rx="22" ry="8.5"/><ellipse cx="37" cy="4" rx="11" ry="8"/><ellipse cx="63" cy="5" rx="11" ry="7.5"/></g><path d="M38 17l-3 6.5M50 17l-3 6.5M62 17l-3 6.5" stroke="var(--ill-1)" stroke-width="2.6" stroke-linecap="round"/>`,
   `<g fill="var(--ill-2)"><ellipse cx="76" cy="10" rx="13" ry="6.5"/><ellipse cx="68" cy="11.5" rx="8" ry="5.5"/></g>`,'',
   `<circle cx="84" cy="13" r="8.5" fill="var(--ill-3)"/><path d="M84 -.5v4M97.5 13h-4M93.5 3.5l-2.8 2.8" stroke="var(--ill-3)" stroke-width="2.6" stroke-linecap="round"/>`,
   spark(14,12,9)+spark(87,8,6)][m-1];
  const body=m===1?'M50 22C76 22 90 40 90 60s-18 34-40 34S10 82 10 60s14-38 40-38z':'M50 15c27 0 41 19 41 41 0 24-17 38-41 38S9 80 9 56c0-22 14-41 41-41z';
  return `<svg class="char" viewBox="-4 -10 108 110" ${label?`role="img" aria-label="${label}"`:'aria-hidden="true"'} focusable="false"><ellipse cx="50" cy="96" rx="28" ry="3.5" fill="var(--ill-ink)" opacity=".08"/><path d="${body}" fill="${c}"/>${acc}${eyes}${mouth}${cheeks}</svg>`;
}
function moonIll(l){ // 1..3 sleep
  const F='var(--face)', fl=(d,w)=>`<path d="${d}" stroke="${F}" stroke-width="${w||2.6}" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`;
  const faceS=l===1?`<circle cx="41.5" cy="50" r="2.8" fill="${F}"/><circle cx="54.5" cy="50" r="2.8" fill="${F}"/>${fl('M42 62q6-4.5 12 0')}`:l===2?`${fl('M38 51h7M51 51h7')}${fl('M43 61h10')}`:`${fl('M38 50q3.5 4 7 0M51 50q3.5 4 7 0')}${fl('M43 59q5 5 10 0')}`;
  const extra=l===1?ln('M14 82l7-5 7 5 7-5 7 5 7-5 7 5 7-5 7 5','2.6','var(--caution)'):l===3?spark(78,20,7)+spark(20,74,5)+ln('M74 30h7l-7 8h7',2.4,'var(--ill-1)'):'';
  return `<svg class="char" viewBox="0 0 96 96" aria-hidden="true" focusable="false"><circle cx="48" cy="52" r="27" fill="var(--ill-moon)"/><path d="M48 25a27 27 0 0 1 0 54 19 27 0 0 0 0-54z" fill="var(--face)" opacity=".07"/><circle cx="36" cy="38" r="2.6" fill="var(--face)" opacity=".1"/><circle cx="60" cy="68" r="3.4" fill="var(--face)" opacity=".1"/>${faceS}${extra}</svg>`;
}
function battIll(l){ // 1..3 energy
  const c=['var(--caution)','var(--ill-3)','var(--ill-1)'][l-1];
  return `<svg class="char" viewBox="0 0 96 96" aria-hidden="true" focusable="false"><rect x="16" y="30" width="58" height="38" rx="9" fill="var(--ill-4)" stroke="var(--ill-ink)" stroke-width="2.5"/><rect x="76" y="42" width="6" height="14" rx="2.5" fill="var(--ill-ink)"/>${[0,1,2].slice(0,l).map(i=>`<rect x="${22+i*17}" y="36" width="13" height="26" rx="3.5" fill="${c}"/>`).join('')}${l===3?`<path d="M50 10l-7 11h9l-7 11" fill="none" stroke="var(--ill-3)" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>`:''}</svg>`;
}
/* Brand mark (matches icon.svg, theme-aware) */
function brandMark(){ return `<svg class="mark" viewBox="0 0 32 32" aria-hidden="true" focusable="false"><rect width="32" height="32" rx="9" fill="var(--pri)"/><g transform="rotate(-38 16 16)"><rect x="7" y="12.2" width="18" height="7.6" rx="3.8" fill="var(--on-pri)"/><path d="M16 12.2h5.2a3.8 3.8 0 0 1 0 7.6H16z" fill="var(--ill-3)"/></g></svg>`; }

'use strict';
/* Medication knowledge (prototype content; a pharmacist should review). Copied verbatim from the original app; only emoji fields were replaced by icon names. */
const DRUGS={
 sertraline:{name:'Sertraline',brand:'Zoloft',mech:'ssri',aka:['sertraline','zoloft'],best:'either',food:'either',sed:false,strengths:[25,50,100],fx:['Nausea','Loose stools','Trouble sleeping','Drowsy','Dizzy','Dry mouth','Sweating','Shaky'],early:'Nausea, loose stools and sleep changes are most common early on.'},
 escitalopram:{name:'Escitalopram',brand:'Lexapro',mech:'ssri',aka:['escitalopram','lexapro'],best:'either',food:'either',sed:false,strengths:[5,10,20],fx:['Nausea','Trouble sleeping','Drowsy','Tired','Sweating','Headache'],early:'Nausea, tiredness and sleep changes are common early on.'},
 citalopram:{name:'Citalopram',brand:'Celexa',mech:'ssri',aka:['citalopram','celexa'],best:'either',food:'either',sed:false,strengths:[10,20,40],fx:['Nausea','Dry mouth','Drowsy','Trouble sleeping','Sweating','Tired'],early:'Nausea, dry mouth and sleepiness are common early on.'},
 fluoxetine:{name:'Fluoxetine',brand:'Prozac',mech:'ssri',aka:['fluoxetine','prozac','sarafem'],best:'morning',food:'either',sed:false,strengths:[10,20,40],fx:['Trouble sleeping','Restless','Nausea','Headache','Less appetite','Shaky'],early:'Some people feel restless at first, so it’s usually a morning medicine.'},
 paroxetine:{name:'Paroxetine',brand:'Paxil',mech:'ssri',aka:['paroxetine','paxil','pexeva'],best:'either',food:'either',sed:true,strengths:[10,20,30,40],fx:['Drowsy','Nausea','Sweating','Dry mouth','Constipation','Dizzy'],early:'Drowsiness and nausea are common early. Don’t stop it suddenly.'},
 venlafaxine:{name:'Venlafaxine XR',brand:'Effexor XR',mech:'snri',aka:['venlafaxine','effexor'],best:'either',food:'with',sed:false,strengths:[37.5,75,150],fx:['Nausea','Dizzy','Sweating','Dry mouth','Trouble sleeping','Constipation','Headache'],early:'Nausea and dizziness are common early. Take it with food.'},
 duloxetine:{name:'Duloxetine',brand:'Cymbalta',mech:'snri',aka:['duloxetine','cymbalta'],best:'either',food:'either',sed:false,strengths:[20,30,60],fx:['Nausea','Dry mouth','Drowsy','Constipation','Tired','Less appetite','Sweating'],early:'Nausea and dry mouth are most common early on.'},
 bupropion:{name:'Bupropion XL',brand:'Wellbutrin XL',mech:'ndri',aka:['bupropion','wellbutrin','aplenzin'],best:'morning',food:'either',sed:false,strengths:[150,300],fx:['Trouble sleeping','Dry mouth','Headache','Restless','Nausea','Less appetite','Shaky'],early:'A morning medicine: later doses can disturb sleep. Swallow whole.',extra:'Tell your prescriber about heavy drinking, seizures or an eating disorder.'},
 mirtazapine:{name:'Mirtazapine',brand:'Remeron',mech:'nassa',aka:['mirtazapine','remeron'],best:'bedtime',food:'either',sed:true,strengths:[7.5,15,30,45],fx:['Drowsy','More appetite','Weight gain','Dry mouth','Dizzy','Constipation'],early:'A bedtime medicine: it makes many people sleepy. Sleep and appetite often improve early.'}
};
const MECH={
 ssri:{title:'It helps your brain’s messages last longer.',chem:[['Serotonin','chem1']],mode:'block'},
 snri:{title:'It keeps two brain messengers around longer.',chem:[['Serotonin','chem1'],['Norepinephrine','chem2']],mode:'block'},
 ndri:{title:'It works on energy & motivation messengers.',chem:[['Dopamine','chem3'],['Norepinephrine','chem2']],mode:'block'},
 nassa:{title:'It turns up how much message gets sent.',chem:[['Serotonin','chem1'],['Norepinephrine','chem2']],mode:'boost'}
};
const WEEKS=[
 {t:'Settling in',e:'Side effects are most likely now.',b:'Benefits usually aren’t felt yet. That’s normal.'},
 {t:'The hard stretch',e:'Side effects often start to ease.',b:'Sleep or energy may shift before mood.'},
 {t:'Turning point',e:'Side effects are usually easing.',b:'Small good signs can show up.'},
 {t:'Check-in week',e:'Lingering effects are usually mild.',b:'Many people notice a lift, often small at first.'},
 {t:'Building',e:'Side effects are usually low or gone.',b:'Benefits keep building.'},
 {t:'Taking stock',e:'Most early effects have settled.',b:'Full benefit can take 6–8 weeks.'}
];
const SUP_WEEK=[n=>`${n} just started. Side effects often come before benefits. Normal, and often the hardest part.`,n=>`Often the hardest stretch: side effects linger and benefits usually haven’t arrived.`,n=>`Side effects usually ease around now. Small good signs can show up.`,n=>`Many people notice a lift around now, often small at first.`,n=>`Benefits usually keep building. Low-key support still matters.`,n=>`Nearly through the first six weeks. Nudges ease off after this.`];
const ILLS=[['Cold or flu','virus'],['Fever','thermometer'],['Stomach bug','stomach'],['Headache','head'],['Allergies','flower'],['Period cramps','droplet'],['Other','plus']];
const ILL_OVERLAP={'Nausea':['Stomach bug','Cold or flu'],'Loose stools':['Stomach bug'],'Headache':['Cold or flu','Headache','Allergies','Fever'],'Tired':['Cold or flu','Fever','Period cramps'],'Drowsy':['Cold or flu','Allergies','Fever'],'Dizzy':['Fever','Cold or flu','Stomach bug'],'Less appetite':['Stomach bug','Cold or flu','Fever'],'Sweating':['Fever'],'Trouble sleeping':['Cold or flu','Fever','Period cramps'],'Constipation':['Period cramps']};
const BODY=[['stomach','stomach','Upset stomach'],['sleep','moon','Hard to sleep'],['drowsy','zzz','Sleepy in the day'],['headache','head','Headaches'],['anxious','zap','Jittery or anxious'],['appetite','plate-minus','Low appetite']];
const HOBBIES=[['Walking','footprints'],['Music','headphones'],['Cooking','pan'],['Reading','book'],['Gaming','gamepad'],['Drawing','pencil'],['Sports','ball'],['Outside','tree'],['Friends','users']];
const SUPPORT_PRESETS=[['Distract me','balloon'],['Text, don’t call','message'],['Food helps','bowl'],['Don’t bring up my meds','pill-off'],['Get me outside','sun-cloud'],['Just sit with me','sofa'],['Plans > questions','calendar']];
const OTHER_COMMON=['Ibuprofen','Birth control','Allergy medicine','ADHD medication','Melatonin','Sleep aid','Blood thinner','Migraine medicine'];
const IX=[
 {keys:['phenelzine','nardil','tranylcypromine','parnate','isocarboxazid','marplan','selegiline','emsam','rasagiline','azilect','linezolid','zyvox','methylene blue'],mechs:['ssri','snri','ndri','nassa'],sev:'avoid',why:'Can be dangerous together. Only if your prescriber planned it.'},
 {keys:['tramadol','ultram'],mechs:['ssri','snri','nassa'],sev:'caution',why:'Raises serotonin syndrome risk. Ask your prescriber.'},
 {keys:['tramadol','ultram'],mechs:['ndri'],sev:'caution',why:'Can raise seizure risk. Ask your prescriber.'},
 {keys:['sumatriptan','imitrex','rizatriptan','maxalt','zolmitriptan','zomig','eletriptan','relpax','migraine'],mechs:['ssri','snri'],sev:'caution',why:'Can raise serotonin syndrome risk. Often fine with guidance; check with your pharmacist.'},
 {keys:['st john','st. john','hypericum'],mechs:['ssri','snri','nassa','ndri'],sev:'avoid',why:'St. John’s wort shouldn’t be combined without your prescriber.'},
 {keys:['dextromethorphan','dxm','robitussin','delsym','lithium','fentanyl','meperidine','demerol','buspirone','buspar','trazodone','5-htp','tryptophan'],mechs:['ssri','snri','nassa'],sev:'caution',why:'Also affects serotonin. Ask your pharmacist.'},
 {keys:['ibuprofen','advil','motrin','naproxen','aleve','aspirin','warfarin','coumadin','apixaban','eliquis','rivaroxaban','xarelto','clopidogrel','plavix','dabigatran','pradaxa','blood thinner'],mechs:['ssri','snri'],sev:'caution',why:'Can raise bleeding risk. Occasional use is often fine; ask your pharmacist.'},
 {keys:['diphenhydramine','benadryl','zzzquil','alprazolam','xanax','lorazepam','ativan','clonazepam','klonopin','diazepam','valium','zolpidem','ambien','gabapentin','neurontin','pregabalin','lyrica','hydroxyzine','oxycodone','hydrocodone','quetiapine','seroquel','cyclobenzaprine','sleep aid','alcohol'],mechs:['ssri','snri','nassa','ndri'],sev:'note',why:'Extra drowsiness together. Careful driving at first.',tag:'sedating'},
 {keys:['methylphenidate','ritalin','concerta','adderall','amphetamine','vyvanse','lisdexamfetamine','modafinil','provigil','adhd'],mechs:['ssri','snri','nassa'],sev:'note',why:'Both can affect sleep. Taking both in the morning helps.',tag:'stimulant'},
 {keys:['methylphenidate','ritalin','concerta','adderall','amphetamine','vyvanse','lisdexamfetamine','adhd'],mechs:['ndri'],sev:'caution',why:'Can add jitteriness, poor sleep and higher blood pressure. Ask your prescriber.',tag:'stimulant'},
 {keys:['tamoxifen'],drugs:['fluoxetine','paroxetine','bupropion'],sev:'caution',why:'May make tamoxifen less effective. Ask your prescriber.'},
 {keys:['pimozide','orap'],drugs:['sertraline','fluoxetine','paroxetine','citalopram','escitalopram'],sev:'avoid',why:'Not recommended together. Talk to your prescriber.'},
 {keys:['thioridazine'],drugs:['fluoxetine','paroxetine','duloxetine'],sev:'avoid',why:'Not recommended together. Talk to your prescriber.'}
];

const FX_ICON={'Nausea':'queasy','Loose stools':'droplets','Trouble sleeping':'moon-star','Drowsy':'zzz','Dizzy':'spiral','Dry mouth':'droplet-off','Sweating':'sweat','Shaky':'wave','Tired':'battery-low','Headache':'head','Restless':'zap','Less appetite':'plate-minus','Constipation':'stomach','More appetite':'plate-plus','Weight gain':'scale','Low mood':'cloud','Timing':'clock'};
const RELATIONS=[['Friend','smile'],['Parent','home'],['Partner','heart'],['Sibling','users'],['Roommate','sofa'],['Coworker','briefcase'],['Other','sparkle']];
const CAPS=[['anchor','anchor','Anchor','~2 nudges a week'],['light','feather','Light touch','~1 every week or two'],['helper','toolbox','Helper','Just specific tasks']];
const TASKS=[['Refills','pill'],['Rides','car'],['Meals','bowl'],['Walks','footprints'],['Late-night texts','moon']];
const THEMES=[
 {id:'botanical',name:'Botanical',desc:'Warm ivory, forest and sage. Gentle and reassuring.'},
 {id:'coastal',name:'Coastal',desc:'Cool white, navy and teal. Clear and airy.'},
 {id:'plum',name:'Plum Editorial',desc:'Pearl, plum and mauve. Elegant, fine lines.'},
 {id:'sandstone',name:'Sandstone',desc:'Sand, cream and terracotta. Grounded, tactile.'},
 {id:'midnight',name:'Midnight',desc:'Deep blue-charcoal and aqua. Made for low light.'}
];
const THEME_MAP={forest:'botanical',plum:'plum',sand:'sandstone',night:'midnight'};

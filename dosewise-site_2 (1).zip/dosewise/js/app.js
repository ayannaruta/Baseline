'use strict';
/* DoseWise app: state, link sharing, logic (carried over from the original), rendering and actions. */
/* ============================================================
   State & storage (this device only)
   ============================================================ */
const LS='dosewise_site_v3';
const fresh=()=>({v:3,role:null,onboarded:false,name:'',phone:'',myId:rid(),
  profile:{wake:'07:00',bed:'23:00',meals:['07:30','12:30','18:30'],stomach:false,sleep:false,drowsy:false,headache:false,anxious:false,appetite:false,custom:[]},
  hobbies:[],supportCard:[],otherMeds:[],med:null,startDate:null,plan:null,logs:{},helped:{},
  circle:null,received:[],supporting:[],theme:'botanical',sample:false});
function rid(){const a='abcdefghjkmnpqrstuvwxyz23456789';let s='';const r=crypto.getRandomValues(new Uint8Array(10));r.forEach(x=>s+=a[x%a.length]);return s;}
let D;
try{D=JSON.parse(localStorage.getItem(LS))||fresh();}catch(e){D=fresh();}
if(!D||D.v!==3) D=fresh();
/* Theme migration: map the four original theme values to the new set. */
D.theme=THEME_MAP[D.theme]||D.theme; if(!THEMES.some(t=>t.id===D.theme)) D.theme='botanical';
const S={tab:'today',view:'me',step:0,ci:null,ciStep:0,overlay:null,toast:null,red:false,photo:null,photoFile:null,scanSource:null,reading:false,ocrPct:0,extract:null,extractErr:null,joinDraft:null,flags:{syn:'with'},deckIdx:{}};
function save(){try{localStorage.setItem(LS,JSON.stringify(D));}catch(e){}}

/* ---------- link encoding (how the circle talks, by text) ---------- */
const BASE=location.href.split('#')[0];
const enc=o=>{const b=new TextEncoder().encode(JSON.stringify(o));let s='';b.forEach(x=>s+=String.fromCharCode(x));return btoa(s).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');};
const dec=s=>{s=s.replace(/-/g,'+').replace(/_/g,'/');while(s.length%4)s+='=';const bin=atob(s);const b=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)b[i]=bin.charCodeAt(i);return JSON.parse(new TextDecoder().decode(b));};
function shareText(text,phone){
  if(navigator.share){ navigator.share({text}).catch(()=>{}); return; }
  const sms='sms:'+(phone||'')+(/iPhone|iPad|Mac/.test(navigator.userAgent)?'&':'?')+'body='+encodeURIComponent(text);
  S.overlay={kind:'share',text,sms}; renderLayer();
}
function snapshot(){
  const c=D.circle; if(!c) return null; const sig=computeSignals();
  return {c:c.code,o:D.name||'Your friend',ph:D.phone||'',w:sig.week,hd:sig.harder,wd:sig.weekendDip,rl:sig.refillLow,rn:sig.refillLeft,h:D.hobbies.slice(0,6),sc:D.supportCard.slice(0,8),st:c.status||null,rd:c.red||null,
    ak:(c.asks||[]).filter(a=>!a.claimedBy&&Date.now()-a.at<5*864e5).slice(-3),m:(c.members||[]).map(m=>({i:m.id,n:m.name,cp:m.cap,pu:m.pausedUntil||null})),pf:sig.prefers,ts:Date.now()};
}
function circleLink(){ return BASE+'#i='+enc(snapshot()); }
function sendToCircle(intro){ const ms=(D.circle.members||[]); const phones=ms.map(m=>m.phone).filter(Boolean).join(','); shareText(`${intro}\n${circleLink()}`,phones); }
function eventLink(code,ev){ return BASE+'#e='+enc(Object.assign({c:code,f:D.myId,n:D.name||'A friend',at:Date.now(),id:rid()},ev)); }
function handleHash(){
  const h=location.hash; if(!h||h.length<4) return;
  try{
    if(h.startsWith('#i=')){ const s=dec(h.slice(3)); if(!s||!s.c) return;
      if(D.circle&&D.circle.code===s.c){ toast('That’s your own circle link.'); }
      else{ const ex=D.supporting.find(x=>x.code===s.c);
        if(ex){ if(!ex.snap||s.ts>=(ex.snap.ts||0)) ex.snap=s; S.view='support'; S.flags.supCode=s.c; toast('Updated: '+s.o); }
        else{ S.joinDraft={snap:s,rel:'',cap:'light',tasks:[],step:0}; if(!D.onboarded&&!D.role) D.role='supporter'; } }
    }
    if(h.startsWith('#e=')){ const e=dec(h.slice(3)); if(D.circle&&D.circle.code===e.c){ importEvent(e); } else toast('That link is for a different circle.'); }
  }catch(err){ toast('That link looks broken. Ask them to send it again.'); }
  try{history.replaceState(null,'',BASE);}catch(e){}
  save();
}
function importEvent(e){
  const c=D.circle; c.members=c.members||[]; c.asks=c.asks||[];
  if(D.received.some(x=>x.id===e.id)) { toast('Already added.'); return; }
  let m=c.members.find(x=>x.id===e.f);
  if(e.t==='join'){ if(!m){ c.members.push({id:e.f,name:e.n,rel:e.r||'',cap:e.cp||'light',tasks:e.tk||[],phone:e.ph||'',joinedAt:e.at}); } else Object.assign(m,{name:e.n,rel:e.r,cap:e.cp,tasks:e.tk||[],phone:e.ph||m.phone}); toast(`${e.n} joined your circle`,'users'); S.tab='circle'; }
  else if(e.t==='pause'){ if(m) m.pausedUntil=e.pu; toast(`${e.n} is taking a short break. The circle has it covered.`); }
  else if(e.t==='cap'){ if(m) m.cap=e.cp; }
  else { if(e.t==='claim'){ const a=c.asks.find(x=>x.id===e.ak); if(a) a.claimedBy=e.n; } D.received.unshift({id:e.id,from:e.f,name:e.n,type:e.t,text:e.x||'',when:e.wh||null,at:e.at}); D.received=D.received.slice(0,60); toast(`${e.n}: ${e.t==='think'?'thinking of you':e.t==='claim'?'got it!':'new message'}`,e.t==='think'?'heart':'message'); S.tab='today'; }
  save();
}

/* ============================================================
   Dates & helpers
   ============================================================ */
const pad=n=>String(n).padStart(2,'0');
const keyOf=d=>d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate());
const todayKey=()=>keyOf(new Date());
const parseKey=k=>{const [y,m,d]=k.split('-').map(Number);return new Date(y,m-1,d);};
const addDays=(k,n)=>{const d=parseKey(k);d.setDate(d.getDate()+n);return keyOf(d);};
const diffDays=(a,b)=>Math.round((parseKey(b)-parseKey(a))/864e5);
const dayNum=()=>D.startDate?Math.max(1,diffDays(D.startDate,todayKey())+1):1;
const weekOf=d=>Math.min(7,Math.ceil(d/7));
const fmtDay=k=>parseKey(k).toLocaleDateString('en-US',{weekday:'short',month:'short',day:'numeric'});
const tmin=t=>{if(!t)return 0;const [h,m]=t.split(':').map(Number);return h*60+m;};
const fromMin=m=>{m=((m%1440)+1440)%1440;return pad(Math.floor(m/60))+':'+pad(m%60);};
const fmtT=t=>{if(!t)return '';let [h,m]=t.split(':').map(Number);const ap=h>=12?'pm':'am';h=h%12||12;return h+':'+pad(m)+' '+ap;};
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const ago=t=>{const m=Math.round((Date.now()-t)/6e4);if(m<1)return 'just now';if(m<60)return m+'m ago';const h=Math.round(m/60);if(h<24)return h+'h ago';return Math.round(h/24)+'d ago';};
const MEALN={1:['your meal'],2:['breakfast','dinner'],3:['breakfast','lunch','dinner'],4:['breakfast','lunch','snack','dinner'],5:['breakfast','snack','lunch','snack','dinner'],6:['breakfast','snack','lunch','snack','dinner','late snack']};
const mealName=(i,n)=>(MEALN[n]||[])[i]||'meal '+(i+1);
const drug=()=>D.med?(DRUGS[D.med.drugId]||D.med.custom):null;
const medName=()=>{const g=drug();return g?g.name.split(' ')[0]:'your medication';};
const isPatient=()=>D.role==='patient'||D.role==='both';
const isSupporter=()=>D.role==='supporter'||D.role==='both'||D.supporting.length>0;
const logsArr=()=>Object.values(D.logs).sort((a,b)=>a.date<b.date?-1:1);
const fmtMg=n=>(Math.round(n*10)/10)+' mg';
function lev(a,b){const m=a.length,n=b.length;if(Math.abs(m-n)>2)return 9;const d=Array.from({length:m+1},(_,i)=>[i]);for(let j=1;j<=n;j++)d[0][j]=j;for(let i=1;i<=m;i++)for(let j=1;j<=n;j++)d[i][j]=Math.min(d[i-1][j]+1,d[i][j-1]+1,d[i-1][j-1]+(a[i-1]===b[j-1]?0:1));return d[m][n];}
function matchDrug(text){ if(!text) return null; const t=text.toLowerCase();
  for(const id in DRUGS) if(DRUGS[id].aka.some(a=>t.includes(a))) return id;
  const words=t.replace(/[^a-z0-9\s]/g,' ').split(/\s+/).filter(w=>/[a-z]/.test(w)).map(w=>w.replace(/0/g,'o').replace(/1/g,'i').replace(/5/g,'s').replace(/8/g,'b')).filter(w=>w.length>=5);
  let best=null,bd=3; for(const id in DRUGS) for(const a of DRUGS[id].aka) for(const w of words){ const d=lev(w,a); if(d<bd&&d<=Math.floor(a.length/4)){bd=d;best=id;} }
  return best; }
function bodyFlags(){ const p=D.profile, f=Object.assign({},p); (p.custom||[]).forEach(x=>{const s=x.toLowerCase(); if(/stomach|nause|gut|digest|reflux|ibs/.test(s)) f.stomach=true; if(/sleep|insomn|awake/.test(s)) f.sleep=true; if(/tired|drows|sleepy|fatigue/.test(s)) f.drowsy=true; if(/anx|jitter|panic|nerv/.test(s)) f.anxious=true;}); return f; }

/* ============================================================
   Logic
   ============================================================ */
function interactions(){
  const g=drug(); if(!g) return []; const id=D.med.drugId, out=[];
  D.otherMeds.forEach(om=>{ const n=om.toLowerCase();
    if(matchDrug(n)){ out.push({with:om,sev:'caution',why:'Also an antidepressant. Sometimes planned; confirm with your prescriber.'}); return; }
    IX.forEach(r=>{ if(!r.keys.some(k=>n.includes(k))) return; if(r.drugs&&!r.drugs.includes(id)) return; if(!r.drugs&&r.mechs&&!r.mechs.includes(g.mech)) return; if(out.some(o=>o.with===om&&o.why===r.why)) return; out.push({with:om,sev:r.sev,why:r.why,tag:r.tag}); });
  });
  return out.sort((a,b)=>({avoid:0,caution:1,note:2})[a.sev]-({avoid:0,caution:1,note:2})[b.sev]);
}
function routineOptions(){
  const g=drug(); if(!g) return []; const p=D.profile, f=bodyFlags(), n=p.meals.length, tags=new Set(interactions().map(i=>i.tag).filter(Boolean));
  const slots=[{id:'wake',label:'When I wake up',time:p.wake,meal:false,ico:'sun'}];
  p.meals.forEach((t,i)=>slots.push({id:'meal'+i,label:'With '+mealName(i,n),time:t,meal:true,ico:'utensils'}));
  slots.push({id:'bed',label:'At bedtime',time:fromMin(tmin(p.bed)-30),meal:false,ico:'moon'});
  return slots.map(s=>{ let sc=0; const pro=[],con=[]; const m=tmin(s.time), morning=m<720, evening=m>=1020, late=m>=900;
    if(g.best==='morning'){ if(morning){sc+=2;pro.push('Best as a morning medicine');} if(late){sc-=3;con.push('Later doses can disturb sleep');} }
    if(g.best==='bedtime'){ if(s.id==='bed'){sc+=3;pro.push('Made for bedtime (sleepy)');} else if(evening) sc+=1; if(morning){sc-=2;con.push('May make you drowsy all day');} }
    if(g.food==='with'){ if(s.meal){sc+=2;pro.push('Needs food: covered');} else {sc-=2;con.push('Needs to be taken with food');} }
    if(f.stomach){ if(s.meal){sc+=1.5;pro.push('Food helps your stomach');} else {sc-=1;con.push('Empty stomach may cause nausea');} }
    if((f.sleep||f.anxious)&&!g.sed){ if(morning){sc+=1;pro.push('Keeps restlessness away from bedtime');} if(evening){sc-=1;con.push('Could make sleep harder');} }
    if(f.drowsy&&(g.sed||g.best==='either')){ if(evening){sc+=1;pro.push('Any drowsiness happens at night');} if(morning&&g.sed){sc-=1;con.push('You’re already sleepy in the day');} }
    if(tags.has('sedating')&&evening){sc+=.5;pro.push('Lines up with your other sleepy med');}
    if(tags.has('stimulant')&&morning){sc+=.5;pro.push('Pairs with your morning stimulant');}
    if(s.meal){sc+=.4;pro.push('Easy habit: attached to a meal');}
    return Object.assign({},s,{score:sc,pro,con}); }).sort((a,b)=>b.score-a.score);
}
function recheckPlan(){ if(!D.plan||!drug()) return; const o=routineOptions().find(x=>x.id===D.plan.id); if(o) Object.assign(D.plan,{time:o.time,label:o.label,food:o.meal}); else D.plan=null; }
function insights(){
  const L=logsArr().filter(l=>l.taken), all=logsArr(), res=[];
  const rate=(a,f)=>a.length?a.filter(f).length/a.length:0, avg=a=>a.reduce((s,l)=>s+l.mood,0)/(a.length||1);
  const stom=l=>l.fx.includes('Nausea')||l.fx.includes('Loose stools');
  const fed=L.filter(l=>l.food),emp=L.filter(l=>!l.food);
  if(emp.length>=2&&fed.length>=2){const a=rate(emp,stom),b=rate(fed,stom);if(a-b>=.25)res.push({k:'food',kind:'how',ico:'utensils',title:'Nausea follows empty-stomach doses',a:['No food',a],b:['With food',b],act:'Try it with a meal.'});}
  const g=drug(), late=L.filter(l=>tmin(l.time)>=1080), early=L.filter(l=>tmin(l.time)<720);
  if(g&&!g.sed&&late.length>=2&&early.length>=2){const a=rate(late,l=>l.sleep===1),b=rate(early,l=>l.sleep===1);if(a-b>=.25)res.push({k:'late',kind:'how',ico:'moon',title:'Evening doses → rougher nights',a:['Evening',a],b:['Morning',b],act:'Sticking to your planned time may help.'});}
  if(g&&g.sed&&early.length>=2&&late.length>=2){const a=rate(early,l=>l.fx.includes('Drowsy')),b=rate(late,l=>l.fx.includes('Drowsy'));if(a-b>=.25)res.push({k:'drowsy',kind:'how',ico:'zzz',title:'Morning doses → drowsy days',a:['Morning',a],b:['Evening',b],act:'Ask your pharmacist about an evening dose.'});}
  const con=all.filter(l=>l.connected),noc=all.filter(l=>l.connected===false);
  if(con.length>=2&&noc.length>=2&&avg(con)-avg(noc)>=.4)res.push({k:'conn',kind:'life',ico:'heart',title:'Days with your people go better',a:['Connected',avg(con)/5],b:['Other days',avg(noc)/5],mood:true});
  const hob=all.filter(l=>l.hobby),noh=all.filter(l=>!l.hobby);
  if(hob.length>=2&&noh.length>=2&&avg(hob)-avg(noh)>=.4)res.push({k:'hobby',kind:'life',ico:'pencil',title:'Doing what you enjoy lifts your mood',a:['Enjoyed something',avg(hob)/5],b:['Other days',avg(noh)/5],mood:true});
  const sun=all.filter(l=>parseKey(l.date).getDay()===0),oth=all.filter(l=>parseKey(l.date).getDay()!==0);
  if(sun.length>=2&&oth.length>=3&&avg(oth)-avg(sun)>=.6)res.push({k:'sunday',kind:'life',ico:'calendar',title:'Sundays tend to be harder',a:['Sundays',avg(sun)/5],b:['Other days',avg(oth)/5],mood:true,act:'Your circle can get a Saturday nudge.'});
  return res;
}
function explain(log){
  const g=drug(); if(!g||!log) return []; const w=weekOf(dayNum()), out=[];
  log.fx.forEach(f=>{
    const ills=(ILL_OVERLAP[f]||[]).filter(x=>log.ills.includes(x));
    if(log.sick&&ills.length){out.push({f,tag:'sick',t:'Maybe being sick',d:`Common with ${ills.join(' or ').toLowerCase()} too.`});return;}
    if((f==='Nausea'||f==='Loose stools')&&log.taken&&!log.food){out.push({f,tag:'how',t:'How you took it',d:'No food today. A meal usually helps.'});return;}
    if(f==='Trouble sleeping'&&log.taken&&!g.sed&&tmin(log.time)>=1020){out.push({f,tag:'how',t:'The timing',d:`Taken at ${fmtT(log.time)}. Earlier may help.`});return;}
    if(f==='Drowsy'&&log.taken&&g.sed&&tmin(log.time)<720){out.push({f,tag:'how',t:'The timing',d:'Taken in the morning; this one makes you sleepy.'});return;}
    if(g.fx.includes(f)){out.push(w<=3?{f,tag:'exp',t:'Expected right now',d:`Common in week ${w}. Usually eases.`}:{f,tag:'ask',t:'Usually eased by now',d:'Mention it to your prescriber.'});return;}
    out.push({f,tag:'ask',t:'Not typical',d:'Ask your pharmacist.'});
  });
  if(log.sick&&log.mood<=2) out.push({f:'Low mood',tag:'sick',t:'Being sick does this',d:'Feeling unwell can feel like the medicine isn’t working. It’s probably just today.'});
  if(log.taken&&D.plan&&Math.abs(tmin(log.time)-tmin(D.plan.time))>120) out.push({f:'Timing',tag:'how',t:'Off your usual time',d:`${fmtT(log.time)} vs your plan, ${fmtT(D.plan.time)}.`});
  return out;
}
function usingRight(){
  const L=logsArr(), g=drug(); if(!L.length||!g||!D.plan) return null;
  const tk=L.filter(l=>l.taken), onT=tk.filter(l=>Math.abs(tmin(l.time)-tmin(D.plan.time))<=90).length, fed=tk.filter(l=>l.food).length;
  const items=[{ok:tk.length/L.length>=.85,ico:'pill',t:`${tk.length}/${L.length} days taken`},{ok:tk.length?onT/tk.length>=.75:true,ico:'clock',t:`${onT}/${tk.length} on time`}];
  if(g.food==='with'||bodyFlags().stomach) items.push({ok:tk.length?fed/tk.length>=.75:true,ico:'utensils',t:`${fed}/${tk.length} with food`});
  const ix=interactions().filter(i=>i.sev!=='note'); items.push({ok:!ix.length,ico:'flask',t:ix.length?`${ix.length} combo${ix.length>1?'s':''} to ask about`:'No flagged combos'});
  return items;
}
function triage(){
  const L=logsArr(), today=D.logs[todayKey()], w=weekOf(dayNum());
  if(today&&today.safety) return {lvl:'red',label:'Reach out now',msg:'You deserve support right now.'};
  const tk=L.filter(l=>l.taken&&!l.sick).slice(-5), avgFx=tk.length?tk.reduce((s,l)=>s+l.fx.length,0)/tk.length:0;
  if(w>=3&&tk.length>=4&&avgFx>=1.5) return {lvl:'orange',label:'Worth a call',msg:`Side effects aren’t easing by week ${w}. Call your prescriber (don’t stop on your own).`};
  if(L.slice(-5).filter(l=>l.mood<=1).length>=3) return {lvl:'orange',label:'Worth a call',msg:'Several very low days. Let your prescriber know.'};
  if(L.slice(-3).filter(l=>!l.taken).length>=2) return {lvl:'yellow',label:'Keep an eye on it',msg:'A couple of missed doses lately.'};
  if(L.slice(-5).filter(l=>l.sleep===1).length>=3) return {lvl:'yellow',label:'Keep an eye on it',msg:'Rough sleep several nights.'};
  return {lvl:'green',label:'On track',msg:''};
}
function pillsLeft(){ const q=D.med&&parseInt(D.med.qty,10); if(!q) return null; return Math.max(0,q-logsArr().filter(l=>l.taken).length); }
function helpedStats(){ const by={}; D.received.forEach(e=>{const h=D.helped[e.id];if(!h)return;by[e.type]=by[e.type]||{y:0,n:0};h==='yes'?by[e.type].y++:by[e.type].n++;}); return by; }
function computeSignals(){
  const t=triage(), w=weekOf(dayNum()), left=pillsLeft(), hs=helpedStats(), pf={};
  Object.keys(hs).forEach(k=>{const s=hs[k];if(s.y+s.n>=2)pf[k]=+(s.y/(s.y+s.n)).toFixed(2);});
  return {week:D.med?w:0,harder:t.lvl==='orange'||(!!D.med&&w<=2),weekendDip:insights().some(i=>i.k==='sunday'),refillLow:left!==null&&left<=7,refillLeft:left,prefers:pf};
}

/* ---------- Personalized check-in prompts that use circle data ---------- */
function circlePrompts(){
  if(!D.circle) return [];
  const out=[], recent=D.received.filter(e=>!D.helped[e.id]&&Date.now()-e.at<3*864e5&&['think','message','plan','claim'].includes(e.type));
  recent.slice(0,2).forEach(e=>{
    if(e.type==='plan'&&e.when&&e.when<=todayKey()) out.push({id:e.id,kind:'plan',q:`Did you get to see ${e.name}?`,sub:`“${e.text}”`});
    else if(e.type==='think') out.push({id:e.id,kind:'think',q:`${e.name} was thinking of you. Did that help?`});
    else if(e.type==='claim') out.push({id:e.id,kind:'claim',q:`${e.name} helped out. Did that help?`});
    else if(e.type!=='plan') out.push({id:e.id,kind:'msg',q:`${e.name} reached out. Did it help?`,sub:e.text?`“${e.text}”`:''});
  });
  return out;
}

/* ---------- Supporter nudges (from the snapshot Maya shares) ---------- */
function nudgeFor(sup){
  const s=sup.snap||{}, me=sup.me, name=s.o||'your friend', w=s.w||1, dow=new Date().getDay(), items=[];
  const hob=(s.h&&s.h[0]||'a walk').toLowerCase(), paused=me.pausedUntil&&me.pausedUntil>=todayKey();
  if(s.rd&&Date.now()-s.rd<72*36e5) items.push({tone:'danger',ico:'heart',title:`Please reach out to ${name} today`,body:'Call or go see them if you can. Worried about safety? Call or text 988 together.',msg:'Thinking about you. Can I call or come by right now?',kind:'message'});
  if(paused) return {items,paused:true};
  const st=s.st&&Date.now()-s.st.at<36*36e5?s.st:null;
  if(st&&st.k==='company'&&me.cap!=='helper') items.push({tone:'acc',ico:'coffee',title:`${name} could use company`,body:'Low-key is perfect.',msg:`Want to hang out today? Maybe ${hob}, or just food.`,kind:'plan'});
  if(st&&st.k==='rough') items.push({tone:'acc',ico:'cloud-rain',title:`${name}’s having a rough day`,body:'No talking needed. A quick “thinking of you” is perfect.',kind:'think'});
  if(s.rl&&(me.tasks||[]).includes('Refills')) items.push({tone:'warn',ico:'pill',title:`Refill soon (${s.rn} left)`,body:'You offered to help with pickups.',msg:'Want me to grab your refill this week?',kind:'message'});
  if(me.cap==='helper'||w>6) return {items,quiet:!items.length};
  const ms=(s.m||[]).filter(x=>x.cp!=='helper'&&!(x.pu&&x.pu>=todayKey()));
  const wk=Math.floor(Date.now()/(7*864e5)), mine=!ms.length||ms[wk%ms.length].i===D.myId, anchors=ms.filter(x=>x.cp==='anchor').length, taper=w>=4;
  const eligible=me.cap==='anchor'?(taper?dow===6:[2,4,6].includes(dow)):(dow===6&&(!taper||wk%2===0)&&(mine||!anchors));
  if(s.wd&&(dow===5||dow===6)&&mine) items.push({tone:'acc',ico:'calendar',title:'Tomorrow’s a good day to connect',body:`Weekends are harder for ${name}. They enjoy ${hob}.`,msg:`Free tomorrow? Thinking ${hob}, low-key.`,kind:'plan'});
  else if(eligible&&s.hd&&(me.cap==='anchor'||!anchors)) items.push({tone:'acc',ico:'sprout',title:`Week ${w}: a harder stretch`,body:'Encouragement beats advice right now.',msg:'Proud of you for sticking with it. Want to do something this week?',kind:'plan'});
  else if(eligible) items.push({tone:'acc',ico:'sparkle',title:`Invite ${name} to something easy`,body:`They enjoy ${(s.h||[]).join(', ').toLowerCase()||'a walk'}.`,msg:`Free this week? Thinking ${hob}.`,kind:'plan'});
  const pf=s.pf||{};
  return {items,quiet:!items.length,prefThink:(pf.think||0)>=(pf.message||0)&&(pf.think||0)>=.6};
}
function sayList(s){
  const say=['“Want to grab food Saturday?”','“Thinking of you, no need to reply.”','“Proud of you.”'], skip=['“Are you taking your meds?”','“Just think positive.”','“You should try…”'], c=(s&&s.sc)||[];
  if(c.some(x=>/meds/i.test(x))) skip.push('Asking about side effects');
  if(c.some(x=>/distract/i.test(x))) skip.push('“How are you feeling?” on repeat');
  if(c.some(x=>/text/i.test(x))) say.push('A text, not a call');
  return {say,skip};
}

/* ============================================================
   On-device photo reading (Tesseract.js OCR, no AI service)
   ============================================================ */
const OCR_SRC='https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/tesseract.min.js';
function loadOCR(){ return window.Tesseract?Promise.resolve(window.Tesseract):new Promise((res,rej)=>{const s=document.createElement('script');s.src=OCR_SRC;s.onload=()=>res(window.Tesseract);s.onerror=()=>rej(new Error('load'));document.head.appendChild(s);}); }
function prepImage(file){ return new Promise((res,rej)=>{ const img=new Image(); img.onload=()=>{ const sc=Math.min(1,1800/Math.max(img.width,img.height)); const c=document.createElement('canvas'); c.width=Math.round(img.width*sc); c.height=Math.round(img.height*sc); const g=c.getContext('2d'); g.drawImage(img,0,0,c.width,c.height); const d=g.getImageData(0,0,c.width,c.height), p=d.data; for(let i=0;i<p.length;i+=4){ let y=.299*p[i]+.587*p[i+1]+.114*p[i+2]; y=clamp((y-128)*1.35+128,0,255); p[i]=p[i+1]=p[i+2]=y; } g.putImageData(d,0,0); res(c); }; img.onerror=rej; img.src=URL.createObjectURL(file); }); }
function parseLabel(raw,source){
  const text=raw.replace(/\r/g,''), lines=text.split('\n').map(l=>l.trim()).filter(Boolean), out={};
  const id=matchDrug(text); if(id) out.drugId=id;
  const sm=text.match(/(\d+(?:[.,]\d+)?)\s*(mg|MG|Mg|mcg)\b/); if(sm) out.mg=parseFloat(sm[1].replace(',','.'));
  const dir=text.match(/\btake\b[^\n]{4,90}(\n\s*[^\n]{0,40}\b(daily|day|bedtime|morning|evening|food|meal)\b[^\n]*)?/i); if(dir) out.directions=dir[0].replace(/\s+/g,' ').trim();
  const qty=text.match(/(?:\bQTY|\bQty|\bqty|\bQuantity|\bQUANTITY|\bDisp(?:ense)?|\bDISP)[\s:.#]*(\d{1,3})\b/)||text.match(/(?:^|\s)#\s?(\d{1,3})\b/); if(qty) out.quantity=qty[1];
  const rf=text.match(/\b(?:Refills?|REFILLS?|RF)\s*[:.]?\s*(\d{1,2}|none|NONE|No|NO|zero)\b/); if(rf) out.refills=/^\d+$/.test(rf[1])?rf[1]:'0';
  const dates=lines.filter(l=>!/DOB|birth/i.test(l)).join('\n').match(/\b\d{1,2}[\/\-.]\d{1,2}[\/\-.]\d{2,4}\b/g);
  if(source==='rx'){
    const pr=text.match(/\b(?:Dr\.?|DR\.?|Prescriber|PRESCRIBER|Prescribed by|Physician)\s*[:.]?\s*([A-Z][A-Za-z.\-' ]{2,30})/); if(pr) out.prescriber=pr[1].trim().replace(/\s{2,}/g,' ');
    const ind=text.match(/\bfor\s+(depression|anxiety|mood|panic|ocd|sleep|pain)\b/i); if(ind) out.indication=ind[1][0].toUpperCase()+ind[1].slice(1).toLowerCase();
    const dw=text.match(/\b(?:Date(?: written)?|Written|Issued)\s*[:.]?\s*(\d{1,2}[\/\-.]\d{1,2}[\/\-.]\d{2,4})/i); if(dw) out.dateWritten=dw[1]; else if(dates) out.dateWritten=dates[0];
  } else {
    const ph=lines.find(l=>/pharmacy|drug|rx\b|cvs|walgreens|rite aid|walmart|kroger/i.test(l)&&l.length<40); if(ph) out.pharmacy=ph.split(/[(\d]/)[0].replace(/[^\w &'.-]/g,'').trim();
    const fd=text.match(/\b(?:Filled|FILLED|Fill Date|DATE FILLED|Date)\s*[:.]?\s*(\d{1,2}[\/\-.]\d{1,2}[\/\-.]\d{2,4})/); if(fd) out.fillDate=fd[1]; else if(dates) out.fillDate=dates[0];
  }
  return out;
}
async function readPhoto(){
  if(!S.photoFile) return; S.reading=true; S.ocrPct=0; S.extractErr=null; render();
  try{
    const T=await loadOCR(); const canvas=await prepImage(S.photoFile);
    const worker=await T.createWorker('eng',1,{logger:m=>{ if(m.status==='recognizing text'){ S.ocrPct=Math.round(m.progress*100); const el=document.getElementById('ocrPct'); if(el) el.textContent=S.ocrPct+'%'; const bar=document.getElementById('ocrBar'); if(bar) bar.style.width=S.ocrPct+'%'; } }});
    const {data}=await worker.recognize(canvas); await worker.terminate();
    const x=parseLabel(data.text||'',S.scanSource);
    S.extract=Object.assign({start:todayKey(),source:S.scanSource},x);
    if(!x.drugId){ S.extractErr='We read the label but couldn’t spot the medicine name. Pick it below.'; S.scanSource='manual'; }
    else { S.step++; }
  }catch(e){ S.extractErr=(!window.Tesseract&&navigator.onLine===false)?'You’re offline. Reading a photo needs a one-time download of the reader, so pick your medicine below for now.':'Couldn’t read that photo here. Try better light, or pick it below.'; S.extract=S.extract||{start:todayKey()}; S.scanSource='manual'; }
  S.reading=false; render();
}

/* ============================================================
   Actions
   ============================================================ */
function obNext(){
  const st=obSteps()[S.step];
  if(st==='medsource'&&S.scanSource==='manual'){ if(!manualOk()) return; S.extract.start=S.extract.start||todayKey(); S.extract.source=S.extract.source||'manual'; }
  if(st==='medconfirm') finalizeMed();
  if(S.step>=obSteps().length-1){ finishOnboarding(); return; }
  S.step++; save(); render();
}
function finalizeMed(){
  const x=S.extract, id=x.drugId;
  D.med={drugId:id,name:DRUGS[id].name,mg:Number(x.mg)||null,directions:x.directions||'',qty:x.quantity||'',refills:x.refills||'',prescriber:x.prescriber||'',pharmacy:x.pharmacy||'',source:x.source||'manual'};
  D.startDate=x.start||todayKey(); const o=routineOptions()[0]; if(o&&(!D.plan||!routineOptions().some(r=>r.id===D.plan.id))) D.plan={id:o.id,time:o.time,label:o.label,food:o.meal};
}
function finishOnboarding(){ D.onboarded=true; S.tab='today'; S.view=isPatient()?'me':'support'; save(); render(); }
function createCircle(){ const a='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';let c='';crypto.getRandomValues(new Uint8Array(6)).forEach(x=>c+=a[x%a.length]); D.circle={code:c,members:[],asks:[],status:null,red:null}; save(); render(); }
function saveCheckin(){
  const c=S.ci, k=todayKey();
  const log={date:k,taken:!!c.taken,time:c.taken?c.time:null,food:!!c.food,sick:!!c.sick,ills:c.sick?c.ills:[],mood:c.mood,sleep:c.sleep,energy:c.energy,fx:c.noFx?[]:c.fx.slice(),hobby:c.hobby||null,connected:c.connected,safety:c.safety===null?null:!!c.safety};
  Object.keys(c.helped).forEach(id=>{D.helped[id]=c.helped[id];if(c.helped[id]==='yes')log.connected=true;});
  if(log.connected===null&&Object.keys(c.helped).length) log.connected=Object.values(c.helped).includes('yes');
  D.logs[k]=log; if(log.hobby&&!D.hobbies.includes(log.hobby)) D.hobbies.push(log.hobby);
  S.ci=null; save(); if(log.safety) S.red=true; else toast('Check-in saved','check-circle');
  render();
}
function sampleData(){
  if(D.sample){ Object.keys(D.logs).forEach(k=>{if(D.logs[k].sample)delete D.logs[k];}); D.sample=false; if(D._realStart){D.startDate=D._realStart;delete D._realStart;} save(); return; }
  const g=drug(); let seed=7; const r=()=>(seed=(seed*16807)%2147483647)/2147483647;
  D._realStart=D.startDate; D.startDate=addDays(todayKey(),-15);
  for(let d=1;d<=15;d++){ const key=addDays(D.startDate,d-1); if(D.logs[key]) continue;
    const w=Math.ceil(d/7), fx=[], late=[3,6,10].includes(d), empty=[2,4,5,8].includes(d), sick=[11,12].includes(d), missed=d===9, base=[.55,.35,.15][w-1]||.1;
    if(!missed){ if(r()<base+(empty?.45:0)) fx.push(g.fx[0]); if(r()<base*.6) fx.push(g.fx[2]||g.fx[1]); if(late&&!g.sed&&g.fx.includes('Trouble sleeping')&&!fx.includes('Trouble sleeping')) fx.push('Trouble sleeping'); }
    const sleep=fx.includes('Trouble sleeping')?1:(r()<.55?3:2), hobby=r()<.4?(D.hobbies[0]||'Walking'):null, conn=r()<.45;
    const mood=clamp(Math.round([2,2.2,2.8][w-1]+(hobby?.6:0)+(conn?.6:0)+(sick?-.8:0)+(parseKey(key).getDay()===0?-.8:0)+(r()-.5)*.6),1,5);
    D.logs[key]={date:key,taken:!missed,time:missed?null:(late?'21:'+pad(10+Math.floor(r()*40)):(D.plan?fromMin(tmin(D.plan.time)+Math.floor(r()*30)-10):'08:00')),food:!empty,sick,ills:sick?['Cold or flu']:[],mood,sleep,energy:clamp(Math.round(mood*.5+sleep*.4),1,3),fx,hobby,connected:conn,safety:d===1||d===8?false:null,sample:true}; }
  D.sample=true; save();
}
function supSend(code,ev,intro){ const sup=D.supporting.find(s=>s.code===code); const link=eventLink(code,ev); shareText(`${intro}\n${link}`,sup&&sup.snap.ph); }


/* ============================================================
   Rendering helpers
   ============================================================ */
const $=s=>document.querySelector(s);
const RM=()=>window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches;
const ap=b=>`aria-pressed="${!!b}"`;
const tick=`<span class="tick" aria-hidden="true">${ic('check')}</span>`;
const nameBit=()=>D.name?', '+esc(D.name):'';
const cap1=s=>s?s[0].toUpperCase()+s.slice(1):s;
function sec(title,body,o={}){
  return `<section class="section ${o.cls||''}" ${o.id?`id="${o.id}"`:''} aria-labelledby="h-${o.hid||slug(title)}"><div class="section-head"><div>${o.eyebrow?`<p class="eyebrow">${o.eyebrow}</p>`:''}<h2 id="h-${o.hid||slug(title)}">${title}</h2></div>${o.action||''}</div>${o.note?`<p class="section-note">${o.note}</p>`:''}${body}</section>`;
}
function slug(t){return String(t).toLowerCase().replace(/<[^>]+>/g,'').replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'').slice(0,40)||'s';}
function iconChips(kind,presets,sel,ph){
  const names=presets.map(x=>x[0]), extra=sel.filter(x=>!names.includes(x));
  return `<div class="chips">${presets.map(([n,e])=>`<button class="chip" ${ap(sel.includes(n))} data-a="toggleList" data-k="${kind}" data-v="${esc(n)}">${ic(e)}${esc(n)}</button>`).join('')}${extra.map(n=>`<button class="chip" aria-pressed="true" data-a="toggleList" data-k="${kind}" data-v="${esc(n)}">${ic('sparkle')}${esc(n)}</button>`).join('')}</div>
  <div class="inline-add" style="margin-top:var(--sp-3)"><label class="sr-only" for="custom-${kind}">${ph}</label><input type="text" id="custom-${kind}" placeholder="${ph}" maxlength="50"><button class="btn quiet" data-a="addCustom" data-k="${kind}">${ic('plus')}Add</button></div>`;
}
function emptyState(art,title,body,action){ return `<div class="center stack-lg" style="align-items:center;padding:var(--sp-7) 0">${art}<div><h2 style="margin-bottom:var(--sp-2)">${title}</h2>${body?`<p class="muted" style="max-width:26rem;margin:0 auto">${body}</p>`:''}</div>${action||''}</div>`; }

/* ============================================================
   Shell: theme, top bar, navigation, screen transitions
   ============================================================ */
const TABS=[['today','Today'],['journey','Journey'],['routine','Routine'],['circle','Circle'],['report','Report']];
let lastKey=null,lastFlow=null,lastIdx=0;
function applyTheme(){
  const t=D.theme||'botanical'; const root=document.documentElement;
  if(root.dataset.theme!==t){ root.dataset.theme=t; const m=document.querySelector('meta[name=theme-color]'); if(m) m.content=getComputedStyle(root).getPropertyValue('--theme-meta').trim()||'#F4F0E8'; }
}
function focusSig(el){
  if(!el||el===document.body||!el.closest) return null;
  if(!el.closest('#screen,#layer,#topbar,#nav')) return null;
  if(el.id) return '#'+CSS.escape(el.id);
  const d=el.dataset; if(!d||!d.a) return null;
  let s=`[data-a="${CSS.escape(d.a)}"]`; ['k','v','i','id','c'].forEach(x=>{ if(d[x]!=null) s+=`[data-${x}="${CSS.escape(d[x])}"]`; });
  return s;
}
function render(){
  const ae=document.activeElement, sig=focusSig(ae), sel=(ae&&'selectionStart' in ae)?[ae.selectionStart,ae.selectionEnd]:null;
  const first=lastKey===null; const changed=renderMain(); renderLayer();
  if(changed&&first) return;
  if(changed){ window.scrollTo(0,0); if(sig||ae===document.body){ const h=$('#screen h1'); if(h&&!S.overlay&&!S.red){ h.setAttribute('tabindex','-1'); h.focus({preventScroll:true}); } } return; }
  if(sig){ const el=document.querySelector(sig); if(el&&el!==document.activeElement){ try{ el.focus({preventScroll:true}); if(sel&&el.setSelectionRange&&/text|tel|search/.test(el.type)) el.setSelectionRange(sel[0],sel[1]); }catch(e){} } }
}
function renderMain(){
  applyTheme();
  const app=$('#app'), sc=$('#screen'), top=$('#topbar'), nav=$('#nav');
  let key,flow=null,idx=0,html,hasNav=false,showSettings=true;
  if(S.joinDraft&&!D.onboarded&&D.role!=='patient'&&D.role!=='both'){ key='join:'+S.joinDraft.step; flow='join'; idx=S.joinDraft.step; html=renderJoin(); showSettings=false; }
  else if(!D.onboarded){ key='ob:'+S.step+':'+(obSteps()[S.step]||'')+':'+(S.scanSource||''); flow='ob'; idx=S.step; html=renderOnboarding(); showSettings=false; }
  else if(S.joinDraft){ key='join:'+S.joinDraft.step; flow='join'; idx=S.joinDraft.step; html=renderJoin(); showSettings=false; }
  else if(S.ci){ key='ci:'+S.ciStep; flow='ci'; idx=S.ciStep; html=renderCheckin(); showSettings=false; }
  else { const both=isPatient()&&isSupporter();
    if(!isPatient()||(both&&S.view==='support')){ key='sup:'+(S.flags.supCode||'')+':'+S.view; html=`<div class="page wide">${both?roleSwitch():''}${renderSupporterHome()}</div>`; }
    else { hasNav=true; key='tab:'+S.tab; html=`<div class="page wide">${both?roleSwitch():''}${({today:renderToday,journey:renderJourney,routine:renderRoutine,circle:renderCircle,report:renderReport})[S.tab]()}</div>`; }
  }
  app.classList.toggle('has-nav',hasNav);
  const sample=D.sample?`<span class="badge sample" title="Includes sample check-ins">${ic('flask')}<span class="lbl" aria-hidden="true">Sample data</span><span class="sr-only">Includes sample data</span></span>`:'';
  const dayPill=(isPatient()&&D.med&&D.onboarded)?`<span class="pill-day">Day ${dayNum()}</span>`:'';
  top.innerHTML=`<a class="brand" href="#main" data-a="home" aria-label="DoseWise home">${brandMark()}<span>Dose<i>Wise</i></span></a><div class="topbar-actions">${D.onboarded&&showSettings?sample+dayPill+`<button class="icon-btn" data-a="settings" aria-label="Settings">${ic('settings','ic-md')}</button>`:''}</div>`;
  if(hasNav){
    nav.innerHTML=`<div class="nav-brand"><span class="brand">${brandMark()}<span>Dose<i>Wise</i></span></span></div>
     <ul class="nav-list">${TABS.map(([t,l])=>`<li><button class="nav-item" data-a="tab" data-v="${t}" ${S.tab===t?'aria-current="page"':''}><span class="pip" aria-hidden="true"></span>${ic(t)}<span>${l}</span></button></li>`).join('')}</ul>
     <div class="nav-foot">${sample}${dayPill}<button class="nav-item" data-a="settings">${ic('settings')}<span>Settings</span></button></div>`;
  } else nav.innerHTML='';
  const changed=key!==lastKey;
  sc.innerHTML=html;
  if(changed){
    const first=sc.firstElementChild; let dir='';
    if(flow&&flow===lastFlow) dir=idx>lastIdx?'fwd':idx<lastIdx?'back':'';
    if(first&&lastKey!==null&&!RM()){ first.classList.add('enter'); if(dir) first.classList.add(dir); }
    lastKey=key; lastFlow=flow; lastIdx=idx;
  }
  after();
  return changed;
}
function roleSwitch(){return `<div class="seg role-switch" role="group" aria-label="Whose view"><button ${ap(S.view!=='support')} data-a="view" data-v="me">${'My medication'}</button><button ${ap(S.view==='support')} data-a="view" data-v="support">People I support</button></div>`;}
function after(){ if(S.flags.needSyn) startSynapse(); }

/* Flow frame shared by onboarding, check-in and join */
function flowFrame(o){
  const steps=o.total>1?`<div class="steps" role="progressbar" aria-label="Progress" aria-valuemin="1" aria-valuemax="${o.total}" aria-valuenow="${o.i+1}">${Array.from({length:o.total},(_,k)=>`<span class="${k<=o.i?'on':''} ${k===o.i?'cur':''}"></span>`).join('')}</div><span class="count">${o.i+1} of ${o.total}</span>`:'<span class="grow"></span>';
  return `<div class="flow-page">
   <div class="flow-head">${o.back?`<button class="back-btn" data-a="${o.back}">${ic('chevron-left')}${o.backLabel||'Back'}</button>`:'<span class="back-btn ghosted" aria-hidden="true">'+ic('chevron-left')+'Back</span>'}${steps}</div>
   <div class="flow-body">${o.art?`<div class="flow-hero">${o.art}</div>`:''}<h1 class="flow-title ${o.center?'center':''}">${o.title}</h1>${o.sub?`<p class="flow-sub ${o.center?'center':''}">${o.sub}</p>`:'<div style="height:var(--sp-5)"></div>'}<div class="flow-content">${o.body}</div></div>
   ${o.foot?`<div class="flow-foot">${o.foot}</div>`:''}</div>`;
}

/* ============================================================
   Onboarding
   ============================================================ */
function obSteps(){
  const pat=['name','day','meals','body','hobbies','support','others','medsource','medconfirm','mechanism','routine','circlesetup'];
  if(!D.role) return ['who'];
  if(D.role==='patient') return ['who',...pat];
  if(D.role==='supporter') return ['who','name','phone'];
  return ['who',...pat];
}
function card(art,title,body,o={}){
  const steps=obSteps(), i=S.step;
  const foot=(o.hideNext?'':`<button class="btn block" data-a="obNext" ${o.nextOk===false?'disabled':''}>${o.next||'Next'}${ic('arrow-right')}</button>`)+(o.skip?`<button class="btn block ghost" data-a="obNext">${o.skip}</button>`:'');
  return flowFrame({back:i>0?'obBack':null,i,total:steps.length>1?steps.length:0,art,title,sub:o.sub,body,foot,center:!!art});
}
function renderOnboarding(){
  const st=obSteps()[S.step], p=D.profile;
  switch(st){
  case 'who': return card(ill('wave','lg'),'Hi! What brings you here?',`<div class="opts" role="radiogroup" aria-label="What brings you here">
    ${[['patient','pill','Starting a medication','Your week-by-week guide.'],['supporter','people','Supporting someone','Help a person you care about.'],['both','heart','Both','Starting one, and supporting someone.']].map(([v,i,t,d])=>`<button class="opt has-tick" role="radio" aria-checked="${D.role===v}" data-a="setRole" data-v="${v}">${ill(i,'sm')}<span><span class="opt-title">${t}</span><span class="opt-desc">${d}</span></span>${tick}</button>`).join('')}</div>`,{nextOk:!!D.role});
  case 'name': return card(ill('wave','lg'),'What should we call you?',`<div class="field"><label class="label" for="ob-name">First name</label><input id="ob-name" type="text" value="${esc(D.name)}" placeholder="First name" data-a="nameIn" autocomplete="given-name"></div>`,{});
  case 'phone': return card(ill('talk','lg'),'Your number',`<div class="field"><label class="label" for="ob-phone">Mobile number <span class="opt-note">(optional)</span></label><input id="ob-phone" type="tel" value="${esc(D.phone)}" placeholder="So texts reach you" data-a="phoneIn" autocomplete="tel"><p class="hint">Only used to pre-fill texts between you and your circle. Stays on this device.</p></div>`,{next:D.phone?'Next':'Skip'});
  case 'day': return card(ill('sunmoon','lg'),'Your usual day',`<div class="grid-2"><div class="field"><label class="label" for="ob-wake">${'Up around'}</label><input id="ob-wake" type="time" value="${p.wake}" data-a="prof" data-k="wake"></div><div class="field" style="margin-top:0"><label class="label" for="ob-bed">Asleep around</label><input id="ob-bed" type="time" value="${p.bed}" data-a="prof" data-k="bed"></div></div>`,{sub:'We use this to suggest a time that fits.'});
  case 'meals': return card(ill('plate','lg'),'How many times do you eat?',mealsEditor(),{});
  case 'body': return card(ill('body','lg'),'Your body’s touchy about…',bodyEditor(true),{sub:'Pick any, or none.'});
  case 'hobbies': return card(ill('star','lg'),'What makes you feel like you?',iconChips('hobby',HOBBIES,D.hobbies,'Add your own…'),{sub:'Your circle sees these, so they can suggest easy plans.'});
  case 'support': return card(ill('heart','lg'),'How do you like support?',iconChips('scard',SUPPORT_PRESETS,D.supportCard,'In your own words…'),{sub:'Your circle sees this.'});
  case 'others': return card(ill('meds','lg'),'Taking anything else?',otherMedsEditor(),{sub:'We’ll flag combos to ask about.',next:D.otherMeds.length?'Next':'Nothing else'});
  case 'medsource': return card(null,'Add your new medication',medSourceBody(),S.scanSource==='manual'?{next:'Continue',nextOk:manualOk(),sub:'Choose it from the list.'}:{hideNext:true,sub:S.scanSource?'':'Pick the quickest way for you.'});
  case 'medconfirm': return card(ill('check','lg'),'Look right?',medConfirmBody(),{next:'Yes, looks right',nextOk:!!(S.extract&&S.extract.drugId&&S.extract.mg)});
  case 'mechanism': { S.flags.needSyn=true; const g=drug(), m=MECH[g.mech]; return card(null,m.title,synapseBox(g)+`<div class="notice info" style="margin-top:var(--sp-4)">${ic('clock')}<p>The effect starts in days, but your brain adapts over weeks. Side effects often come first.</p></div>`,{}); }
  case 'routine': return card(null,'When works for you?',routinePicker(),{sub:'Ranked using everything you told us. You choose.',next:'Use this time',nextOk:!!D.plan});
  case 'circlesetup': return card(ill('people','lg'),'Bring your people along?',D.circle?inviteBox():`<p class="muted center" style="margin-bottom:var(--sp-5)">They get gentle nudges to check in. Never your check-ins.</p><div class="field"><label class="label" for="cs-phone">Your number <span class="opt-note">(optional)</span></label><input id="cs-phone" type="tel" value="${esc(D.phone)}" placeholder="So their texts reach you" data-a="phoneIn"></div><button class="btn block secondary" style="margin-top:var(--sp-5)" data-a="createCircle">${ic('users')}Create my circle</button>`,D.circle?{next:'Start'}:{hideNext:true,skip:'Maybe later'});
  }
  return '';
}
function mealsEditor(){ const p=D.profile;
  return `<div class="stepper"><button class="icon-btn outlined" data-a="meals" data-v="-1" aria-label="Fewer meals" ${p.meals.length<=1?'disabled':''}>${ic('minus')}</button><span class="num-display" aria-live="polite" aria-label="${p.meals.length} meals">${p.meals.length}</span><button class="icon-btn outlined" data-a="meals" data-v="1" aria-label="More meals" ${p.meals.length>=6?'disabled':''}>${ic('plus')}</button></div>
    <div class="card tight">${p.meals.map((t,i)=>`<div class="time-row"><label class="row" for="meal-${i}">${ic('utensils','ic-sm')}${mealName(i,p.meals.length)}</label><input id="meal-${i}" type="time" value="${t}" data-a="mealTime" data-i="${i}"></div>`).join('')}</div>`;
}
function bodyEditor(tiles){ const p=D.profile;
  return `${tiles?`<div class="tiles compact">${BODY.map(([k,e,l])=>`<button class="tile" ${ap(p[k])} data-a="pflag" data-k="${k}">${ic(e)}${l}${tick}</button>`).join('')}</div>`:`<div class="chips">${BODY.map(([k,e,l])=>`<button class="chip" ${ap(p[k])} data-a="pflag" data-k="${k}">${ic(e)}${l}</button>`).join('')}</div>`}
    ${(p.custom||[]).length?`<div class="chips" style="margin-top:var(--sp-3)">${p.custom.map(x=>`<button class="chip removable" aria-pressed="true" data-a="rmBody" data-v="${esc(x)}" aria-label="Remove ${esc(x)}">${esc(x)}${ic('x','ic-sm x')}</button>`).join('')}</div>`:''}
    <div class="inline-add" style="margin-top:var(--sp-3)"><label class="sr-only" for="custom-body">Something else</label><input type="text" id="custom-body" placeholder="Something else? e.g. reflux, migraines" maxlength="50"><button class="btn quiet" data-a="addBody">${ic('plus')}Add</button></div>`;
}
function otherMedsEditor(){
  return `${D.otherMeds.length?`<div class="chips" style="margin-bottom:var(--sp-3)">${D.otherMeds.map(m=>`<button class="chip removable" aria-pressed="true" data-a="rmOther" data-v="${esc(m)}" aria-label="Remove ${esc(m)}">${ic('pill')}${esc(m)}${ic('x','ic-sm x')}</button>`).join('')}</div>`:''}
   <div class="inline-add"><label class="sr-only" for="otherIn">Medication name</label><input type="text" id="otherIn" placeholder="Type a name"><button class="btn quiet" data-a="addOther">${ic('plus')}Add</button></div>
   <p class="eyebrow" style="margin:var(--sp-4) 0 var(--sp-2)">Common</p><div class="chips">${OTHER_COMMON.filter(x=>!D.otherMeds.includes(x)).map(x=>`<button class="chip add" data-a="addOtherV" data-v="${x}">${ic('plus')}${x}</button>`).join('')}</div>`;
}
function medSourceBody(){
  if(S.scanSource==='rx'||S.scanSource==='bottle'){
    const what=S.scanSource==='rx'?'your prescription':'the bottle label';
    return `<button class="link" data-a="srcReset">${ic('chevron-left','ic-sm')}Other ways</button>
     <button class="upload" data-a="pick" style="margin-top:var(--sp-3)" ${S.reading?'disabled':''}>${S.photo?`<img src="${S.photo}" alt="Your photo of ${what}"><span class="small muted">${S.reading?'Reading…':'Tap to choose a different photo'}</span>`:`${ill(S.scanSource==='rx'?'rx':'bottle','lg')}<span style="font-weight:var(--strong-wt);display:inline-flex;gap:.5rem;align-items:center">${ic('camera')}Snap or upload ${what}</span><span class="tiny muted">Flat, bright, label facing you</span>`}</button>
     ${S.reading?`<div class="ocr" role="status" aria-live="polite" style="margin-top:var(--sp-4)"><div class="row"><span class="spinner" aria-hidden="true"></span><span class="grow">Reading on your device…</span><b id="ocrPct">${S.ocrPct}%</b></div><div class="bar"><span id="ocrBar" style="width:${S.ocrPct}%"></span></div><p class="tiny muted">The first time downloads the reader (about 10 MB).</p></div>`:''}
     ${S.photo&&!S.reading?`<button class="btn block" style="margin-top:var(--sp-4)" data-a="readPhoto">${ic('sparkle')}Read it</button>`:''}
     ${!S.reading&&navigator.onLine===false&&!window.Tesseract?`<div class="notice warn" style="margin-top:var(--sp-4)">${ic('alert')}<p>You’re offline. Reading a photo needs a one-time download, so you can pick it yourself for now.</p></div>`:''}
     <p class="privacy" style="margin-top:var(--sp-4);justify-content:center">${ic('lock')}Read on your device. The photo never leaves it.</p>`;
  }
  if(S.scanSource==='manual'){ const x=S.extract||{}; const g=x.drugId?DRUGS[x.drugId]:null;
    return `<button class="link" data-a="srcReset">${ic('chevron-left','ic-sm')}Other ways</button>${S.extractErr?`<div class="notice warn" role="alert" style="margin-top:var(--sp-3)">${ic('alert')}<p>${esc(S.extractErr)}</p></div>`:''}
     <div class="field" style="margin-top:var(--sp-4)"><span class="label" id="lbl-med">Medication</span><div class="chips" role="radiogroup" aria-labelledby="lbl-med">${Object.keys(DRUGS).map(k=>`<button class="chip" role="radio" aria-checked="${x.drugId===k}" ${ap(x.drugId===k)} data-a="manDrug" data-v="${k}">${DRUGS[k].name.split(' ')[0]}</button>`).join('')}</div></div>
     ${g?`<div class="field" style="margin-top:var(--sp-5)"><label class="label" for="mgIn">Strength</label><div class="big-num"><input id="mgIn" type="number" inputmode="decimal" min="0" step="0.5" value="${x.mg||''}" data-a="mgIn" placeholder="0"><span class="unit">mg</span></div>
       <div class="chips" style="margin-top:var(--sp-3)">${g.strengths.map(s=>`<button class="chip" ${ap(x.mg===s)} data-a="mgPick" data-v="${s}">${s} mg</button>`).join('')}</div></div>
       <div class="field" style="margin-top:var(--sp-5)"><label class="label" for="qtyIn">Tablets in the bottle <span class="opt-note">(optional)</span></label><div class="big-num"><input id="qtyIn" type="number" inputmode="numeric" min="0" step="1" value="${x.quantity||''}" data-a="qtyIn" placeholder="30"><span class="unit">tabs</span></div></div>`:''}`; }
  return `<div class="opts"><button class="opt" data-a="src" data-v="rx">${ill('rx','sm')}<span><span class="opt-title">Scan prescription <span class="badge">Recommended</span></span><span class="opt-desc">Most detail</span></span>${ic('chevron-right','chev')}</button>
   <button class="opt" data-a="src" data-v="bottle">${ill('bottle','sm')}<span><span class="opt-title">Photo of the bottle</span><span class="opt-desc">Quick, fewer details</span></span>${ic('chevron-right','chev')}</button>
   <button class="opt" data-a="src" data-v="manual">${ill('list','sm')}<span><span class="opt-title">Pick it myself</span><span class="opt-desc">Choose from a list</span></span>${ic('chevron-right','chev')}</button></div>`;
}
function manualOk(){ const x=S.extract; return !!(x&&x.drugId&&x.mg>0); }
const RX_F=[['directions','Directions'],['quantity','Quantity'],['refills','Refills'],['prescriber','Prescriber'],['dateWritten','Written'],['indication','For']];
const BOT_F=[['directions','Directions'],['quantity','Quantity'],['refills','Refills'],['pharmacy','Pharmacy'],['fillDate','Filled']];
function medConfirmBody(){
  const x=S.extract||{}, g=x.drugId?DRUGS[x.drugId]:null, src=x.source||S.scanSource;
  const fields=(src==='rx'?RX_F:src==='bottle'?BOT_F:[]).filter(([k])=>x[k]);
  return `<div class="stack-lg"><div class="card med-confirm"><div class="display">${g?g.name:'?'}</div><div class="muted small">${g?g.brand:''}</div>
    <div class="big-num" style="justify-content:center;margin-top:var(--sp-4)"><label class="sr-only" for="mgIn">Strength in mg</label><input id="mgIn" type="number" inputmode="decimal" min="0" step="0.5" value="${x.mg||''}" data-a="mgIn"><span class="unit">mg</span></div></div>
    <div class="card tight"><dl class="kv inputs">${fields.map(([k,l])=>`<dt><label for="ex-${k}">${l}</label></dt><dd><input id="ex-${k}" type="text" value="${esc(x[k])}" data-a="exField" data-k="${k}"></dd>`).join('')}<dt><label for="ex-start">Started</label></dt><dd><input id="ex-start" type="date" value="${esc(x.start||todayKey())}" data-a="exField" data-k="start"></dd></dl></div>
    ${src==='rx'||src==='bottle'?`<p class="source-note" style="justify-content:center">${ic('info')}Read from your ${src==='rx'?'prescription':'bottle'}. Only what we found is shown.</p>`:''}
    <div class="center"><button class="link" data-a="srcManualFix">Wrong medicine? Pick it myself</button></div></div>`;
}
function synapseBox(g){ const m=MECH[g.mech];
  return `<div class="card tight"><div class="seg" role="group" aria-label="Compare" style="margin-bottom:var(--sp-3)"><button ${ap(S.flags.syn!=='with')} data-a="syn" data-v="without">Before</button><button ${ap(S.flags.syn==='with')} data-a="syn" data-v="with">With ${esc(g.name.split(' ')[0])}</button></div>
    <canvas id="syn" class="synapse" width="680" height="360" role="img" aria-label="Animation of brain messengers passing between two nerve cells. ${esc(m.title)}"></canvas>
    <div class="legend">${m.chem.map(([n,c])=>`<span><i style="background:var(--c-${c})"></i>${n}</span>`).join('')}<span><i style="background:var(--c-pump)"></i>${m.mode==='boost'?'Brake':'Recycling pump'}</span></div>
    <div style="margin-top:var(--sp-4)"><div class="row between small"><span class="muted">Message strength</span><b id="sigv" aria-live="off">–</b></div><div class="bar" style="margin-top:var(--sp-2)"><span id="sigb" style="width:0"></span></div></div></div>`; }
function routinePicker(){
  const opts=routineOptions(); if(!opts.length) return '';
  return `<div class="opts" role="radiogroup" aria-label="Dose time">${opts.map((o,i)=>`<button class="opt top has-tick" role="radio" aria-checked="${!!(D.plan&&D.plan.id===o.id)}" data-a="pickPlan" data-v="${o.id}"><span class="ico-badge ${D.plan&&D.plan.id===o.id?'':'plain'}">${ic(o.ico)}</span><span class="grow"><span class="opt-title">${o.label} · ${fmtT(o.time)} ${i===0?'<span class="badge">Best fit</span>':''}</span><ul class="pros">${o.pro.slice(0,2).map(x=>`<li class="pro">${ic('check')}${x}</li>`).join('')}${o.con.slice(0,1).map(x=>`<li class="con">${ic('x')}${x}</li>`).join('')}</ul></span>${tick}</button>`).join('')}</div>`;
}
function inviteBox(){
  return `<div class="card invite"><div class="grow"><p class="eyebrow">Circle code</p><div class="code">${D.circle.code}</div><p class="small muted" style="margin-top:var(--sp-1)">Invite by text. They tap the link, no account needed.</p></div><button class="btn secondary" data-a="invite">${ic('send')}Send an invite</button></div>`;
}

/* ============================================================
   Today
   ============================================================ */
function renderToday(){
  const k=todayKey(), log=D.logs[k], t=triage(), g=drug(), w=weekOf(dayNum()), W=WEEKS[Math.min(5,w-1)];
  if(!g) return emptyState(ill('pill','xl'),`Hi${nameBit()}!`,'Add the medication you’re starting to get your week-by-week guide.',`<button class="btn" data-a="addMed">${ic('plus')}Add your medication</button>`);
  const recv=D.received.filter(e=>Date.now()-e.at<36*36e5&&['think','message','plan','claim'].includes(e.type)).slice(0,3);
  const lvlCls={red:'urgent',orange:'caution',yellow:'warn'}[t.lvl];
  let head=`<header class="page-head greet"><div><p class="eyebrow">${fmtDay(k)}</p><h1>${log?'Nice work':greet()}${nameBit()}.</h1>
    <div class="med-line"><span>${ic('pill')}${esc(g.name)}${D.med.mg?' '+fmtMg(D.med.mg):''}</span>${D.plan?`<span>${ic('clock')}${fmtT(D.plan.time)} · ${esc(D.plan.label.toLowerCase())}</span>`:''}<span>${ic('calendar')}Day ${dayNum()} · Week ${Math.min(6,w)}</span></div></div>
    <div class="head-side"><span class="status s-${t.lvl}"><span class="dot"></span>${t.label}</span></div></header>`;
  const alert=t.lvl!=='green'?`<div class="notice lead ${lvlCls}" role="${t.lvl==='red'?'alert':'status'}" style="margin-bottom:var(--section-gap)">${ic(t.lvl==='yellow'?'info':'alert')}<div class="grow"><p class="notice-title">${t.label}</p><p>${t.msg}</p>${t.lvl==='orange'?`<div class="btn-row"><button class="btn sm" data-a="tab" data-v="report">${ic('phone')}Call script</button></div>`:t.lvl==='red'?`<div class="btn-row"><button class="btn sm danger" data-a="openRed">${ic('phone')}Get support now</button></div>`:''}</div></div>`:'';
  let main='';
  if(!log) main+=`<section class="focus-card" aria-labelledby="ci-h"><span class="ring" aria-hidden="true"></span><div style="position:relative"><p class="eyebrow" style="color:inherit;opacity:.8">Daily check-in</p><h2 id="ci-h">How’s today going?</h2><p>About 30 seconds${D.plan?` · ${esc(medName())} at ${fmtT(D.plan.time)}`:''}</p><button class="btn" data-a="startCi">Check in${ic('arrow-right')}</button></div>${blob(3)}</section>`;
  else { const ex=explain(log), M=MOOD[log.mood-1];
    main+=`<section class="card" aria-labelledby="done-h"><div class="done-card">${blob(log.mood,'Mood: '+M.w)}<div class="grow"><p class="eyebrow">Checked in</p><h2 id="done-h" style="margin:.1rem 0 0">Feeling ${M.w.toLowerCase()}</h2>
      <div class="facts"><span class="fact">${ic(log.taken?'check-circle':'clock')}${log.taken?`Taken ${fmtT(log.time)}`:'Not taken yet'}</span>${log.taken?`<span class="fact">${ic('utensils')}${log.food?'With food':'No food'}</span>`:''}${log.sick?`<span class="fact">${ic('thermometer')}Under the weather</span>`:''}</div></div>
      <button class="btn quiet sm" data-a="editCi" aria-label="Edit today’s check-in">${ic('pencil')}Edit</button></div></section>`;
    main+=ex.length?sec('Why might I feel this way?',`<div class="card"><ul class="why">${ex.map(e=>`<li><span class="ico-badge sm plain">${ic(FX_ICON[e.f]||'info')}</span><div class="grow"><div class="row wrap" style="gap:.5rem"><b>${esc(e.f)}</b><span class="tag t-${e.tag}">${e.t}</span></div><p class="small muted">${e.d}</p></div></li>`).join('')}</ul></div>`,{note:'Based on what you logged today.'})
      :`<div class="notice ok">${ic('leaf')}<p>No side effects today.</p></div>`;
    const nx=[];
    if(D.plan) nx.push(`<li><span class="ico-badge sm">${ic('clock')}</span><span class="grow"><span class="list-title">Tomorrow’s dose</span><span class="list-sub" style="display:block">${fmtT(D.plan.time)} · ${esc(D.plan.label.toLowerCase())}</span></span></li>`);
    nx.push(D.circle?`<li><span class="ico-badge sm sec">${ic('users')}</span><span class="grow"><span class="list-title">Let your people know</span><span class="list-sub" style="display:block">Send a quick update to your circle</span></span><button class="btn ghost sm" data-a="tab" data-v="circle">Open${ic('arrow-right','ic-sm')}</button></li>`:`<li><span class="ico-badge sm sec">${ic('users')}</span><span class="grow"><span class="list-title">Bring your people along</span><span class="list-sub" style="display:block">Gentle nudges for them, privacy for you</span></span><button class="btn ghost sm" data-a="tab" data-v="circle">Set up${ic('arrow-right','ic-sm')}</button></li>`);
    nx.push(`<li><span class="ico-badge sm plain">${ic('report')}</span><span class="grow"><span class="list-title">Prescriber summary</span><span class="list-sub" style="display:block">Ready when you want to talk it through</span></span><button class="btn ghost sm" data-a="tab" data-v="report">View${ic('arrow-right','ic-sm')}</button></li>`);
    main+=sec('Up next',`<div class="card tight"><ul class="list no-top">${nx.join('')}</ul></div>`);
  }
  let side='';
  if(recv.length) side+=sec('From your circle',`<div class="card tight"><ul class="list no-top">${recv.map(e=>`<li><span class="ico-badge sm sec">${ic(e.type==='think'?'heart':e.type==='plan'?'calendar':e.type==='claim'?'hand':'message')}</span><div class="grow"><p class="small"><b>${esc(e.name)}</b> ${e.type==='think'?'is thinking of you':e.type==='claim'?'has it covered':''}${e.text?` “${esc(e.text)}”`:''}</p><p class="tiny muted">${ago(e.at)}</p></div></li>`).join('')}</ul></div>`);
  side+=`<section class="card" aria-labelledby="wk-h"><div class="week-strip">${weekDial(w)}<div class="grow"><p class="eyebrow">Week ${Math.min(6,w)} of 6</p><h3 id="wk-h">${W.t}</h3></div></div><p class="small" style="margin-top:var(--sp-3)">${w===1&&g.early?g.early:W.e}</p><button class="link" data-a="tab" data-v="journey" style="margin-top:var(--sp-2)">See your journey${ic('arrow-right','ic-sm')}</button></section>`;
  const left=pillsLeft(); if(left!==null&&left<=7) side+=`<div class="notice warn">${ic('pill')}<div class="grow"><p class="notice-title">About ${left} doses left</p><p>Time for a refill.</p>${D.circle?'<div class="btn-row"><button class="btn sm quiet" data-a="askQuick" data-v="Can someone help pick up my refill?">Ask my circle</button></div>':''}</div></div>`;
  side+=`<button class="support-link" data-a="openRed">${ic('heart')}Need support right now?</button>`;
  return head+alert+`<div class="cols"><div class="col">${main}</div><div class="col col-side">${side}</div></div>`;
}
function weekDial(w){ const p=Math.min(1,dayNum()/42), r=24, C=2*Math.PI*r;
  return `<div class="week-dial" aria-hidden="true"><svg viewBox="0 0 56 56"><circle cx="28" cy="28" r="${r}" fill="none" stroke="var(--c-bar)" stroke-width="5"/><circle cx="28" cy="28" r="${r}" fill="none" stroke="var(--pri)" stroke-width="5" stroke-linecap="round" stroke-dasharray="${(C*p).toFixed(1)} ${C.toFixed(1)}"/></svg><b>${Math.min(6,w)}</b></div>`; }
const greet=()=>{const h=new Date().getHours();return h<12?'Good morning':h<17?'Hi':'Good evening';};

/* ============================================================
   Check-in
   ============================================================ */
function ciCards(){
  const cards=['taken','health','mood','sleep','fx','enjoy'];
  if(D.circle) cards.push('connect');
  const lastS=logsArr().filter(l=>l.safety!==null&&l.safety!==undefined&&l.date!==todayKey()).slice(-1)[0];
  if(dayNum()<=2||!lastS||diffDays(lastS.date,todayKey())>=6||S.ci.safety!==null) cards.push('safety');
  return cards;
}
const illTile=(on,attrs,art,label)=>`<button class="tile" ${ap(on)} ${attrs}>${art}<span>${label}</span>${tick}</button>`;
function renderCheckin(){
  const c=S.ci, cards=ciCards(), i=S.ciStep, k=cards[i], g=drug(), prev=logsArr().filter(l=>l.date!==todayKey()).slice(-1)[0];
  let title='',body='',ok=true,sub='';
  if(k==='taken'){ title=`Did you take your ${esc(medName())} today?`; ok=c.taken!==null;
    body=`<div class="tiles two">${illTile(c.taken===true,'data-a="ci" data-k="taken" data-v="1"',ill('check','md','bare'),'Yes, took it')}${illTile(c.taken===false,'data-a="ci" data-k="taken" data-v="0"',ill('notyet','md','bare'),'Not yet')}</div>
     ${c.taken?`<div class="card" style="margin-top:var(--sp-4)"><div class="field"><label class="label" for="ciTime">About when?</label><input id="ciTime" type="time" value="${c.time}" data-a="ciTime"></div>
      <div class="field"><span class="label" id="lbl-food">Had you eaten?</span><div class="tiles two" role="group" aria-labelledby="lbl-food">${illTile(c.food,'data-a="ci" data-k="food" data-v="1"',ill('food','md','bare'),'Yes')}${illTile(c.food===false,'data-a="ci" data-k="food" data-v="0"',ill('nofood','md','bare'),'No')}</div></div>
      ${D.plan&&Math.abs(tmin(c.time)-tmin(D.plan.time))>120?`<p class="small row" style="color:var(--warn-text);margin-top:var(--sp-3);gap:.4rem">${ic('clock','ic-sm')}A bit off your usual ${fmtT(D.plan.time)}. No stress.</p>`:''}</div>`:''}`; }
  if(k==='health'){ title=prev&&prev.sick?'Still under the weather?':'Apart from meds, how’s your body?'; ok=c.sick!==null;
    body=`<div class="tiles two">${illTile(c.sick===false,'data-a="ci" data-k="sick" data-v="0"',ill('leaf','md','bare'),'Healthy')}${illTile(c.sick===true,'data-a="ci" data-k="sick" data-v="1"',ill('thermo','md','bare'),'Under the weather')}</div>
     ${c.sick?`<div class="chips" style="margin-top:var(--sp-4)">${ILLS.map(([x,e])=>`<button class="chip" ${ap(c.ills.includes(x))} data-a="ciList" data-k="ills" data-v="${x}">${ic(e)}${x}</button>`).join('')}</div><p class="small muted" style="margin-top:var(--sp-3)">We’ll factor it in. Being sick can feel like the medicine isn’t working.</p>`:''}`; }
  if(k==='mood'){ title='Which one feels like today?'; ok=!!c.mood; const M=c.mood?MOOD[c.mood-1]:null;
    body=`<div class="mood-pick"><div class="mood-stage ${M?'':'placeholder'}" aria-hidden="true">${blob(c.mood||3)}<div class="w">${M?M.w:'Pick one'}</div><p class="muted small">${M?M.d:'Tap the face that fits, or use the arrow keys'}</p></div>
      <div class="mood-opts" role="radiogroup" aria-label="Mood today">${MOOD.map((m,j)=>`<button class="mood-opt" role="radio" aria-checked="${c.mood===j+1}" tabindex="${(c.mood?c.mood===j+1:j===2)?0:-1}" data-a="moodPick" data-v="${j+1}" aria-label="${m.w}: ${m.d}">${blob(j+1)}<span aria-hidden="true">${m.w}</span></button>`).join('')}</div></div>`; }
  if(k==='sleep'){ title='Sleep and energy'; ok=!!c.sleep&&!!c.energy;
    body=`<div class="field"><span class="label" id="lbl-sleep">Last night</span><div class="tiles" role="group" aria-labelledby="lbl-sleep">${['Restless','So-so','Slept well'].map((x,j)=>illTile(c.sleep===j+1,`data-a="ci" data-k="sleep" data-v="${j+1}"`,moonIll(j+1),x)).join('')}</div></div>
     <div class="field" style="margin-top:var(--sp-5)"><span class="label" id="lbl-en">Energy today</span><div class="tiles" role="group" aria-labelledby="lbl-en">${['Low','Okay','Charged'].map((x,j)=>illTile(c.energy===j+1,`data-a="ci" data-k="energy" data-v="${j+1}"`,battIll(j+1),x)).join('')}</div></div>`; }
  if(k==='fx'){ title='Notice any of these?'; ok=c.fx.length>0||c.noFx; sub='Pick all that apply.';
    body=`<div class="tiles compact">${g.fx.map(x=>`<button class="tile" ${ap(c.fx.includes(x))} data-a="ciList" data-k="fx" data-v="${x}">${ic(FX_ICON[x]||'info')}${x}${tick}</button>`).join('')}<button class="tile" ${ap(c.noFx)} data-a="ci" data-k="noFx" data-v="1">${ic('leaf')}None${tick}</button></div>`; }
  if(k==='enjoy'){ const h0=D.hobbies[0]; const lastH=logsArr().filter(l=>l.hobby).slice(-1)[0];
    title=lastH&&diffDays(lastH.date,todayKey())>=3?`It’s been a few days since ${esc(lastH.hobby.toLowerCase())}. Any time for it today?`:h0?`Any ${esc(h0.toLowerCase())} or fun today?`:'Do anything you enjoy today?'; ok=c.hobby!==null;
    const hs=D.hobbies.length?D.hobbies:['Something fun'];
    body=`<div class="chips">${hs.map(x=>{const e=(HOBBIES.find(h=>h[0]===x)||[0,'sparkle'])[1];return `<button class="chip" ${ap(c.hobby===x)} data-a="ci" data-k="hobby" data-v="${esc(x)}">${ic(e)}${esc(x)}</button>`;}).join('')}<button class="chip" ${ap(c.hobby==='')} data-a="ci" data-k="hobby" data-v="">Not today</button></div>
     <div class="inline-add" style="margin-top:var(--sp-4)"><label class="sr-only" for="ciHobby">Something else</label><input type="text" id="ciHobby" placeholder="Something else…" maxlength="40"><button class="btn quiet" data-a="ciHobbyAdd">${ic('plus')}Add</button></div>`; }
  if(k==='connect'){ const pr=circlePrompts(), mem=(D.circle.members||[]);
    if(pr.length){ title=pr[0].q; ok=pr.every(p=>c.helped[p.id]);
      body=pr.map((p,j)=>`${j?`<h2 style="margin-top:var(--sp-6);margin-bottom:var(--sp-2)">${esc(p.q)}</h2>`:''}${p.sub?`<p class="small muted" style="margin-bottom:var(--sp-3)">${esc(p.sub)}</p>`:''}
        <div class="tiles two">${illTile(c.helped[p.id]==='yes',`data-a="ciHelp" data-id="${p.id}" data-v="yes"`,ic(p.kind==='plan'?'check-circle':'heart'),p.kind==='plan'?'Yes!':'It helped')}${illTile(c.helped[p.id]==='no',`data-a="ciHelp" data-id="${p.id}" data-v="no"`,ic(p.kind==='plan'?'calendar':'minus'),p.kind==='plan'?'Not yet':'Not really')}</div>`).join('')+`<p class="privacy" style="margin-top:var(--sp-4)">${ic('lock')}Private. Only tunes future nudges.</p>`; }
    else { const names=mem.map(m=>m.name).slice(0,2); title=names.length?`See or talk to ${names.map(esc).join(' or ')} today?`:'Talk to anyone you care about today?'; ok=c.connected!==null;
      body=`<div class="tiles two">${illTile(c.connected===true,'data-a="ci" data-k="connected" data-v="1"',ill('talk','md','bare'),'Yes')}${illTile(c.connected===false,'data-a="ci" data-k="connected" data-v="0"',ill('alone','md','bare'),'Not today')}</div>`; } }
  if(k==='safety'){ title='One weekly check'; ok=c.safety!==null;
    body=`<p style="margin-bottom:var(--sp-5);font-size:var(--fs-lg)">Lately, any thoughts of hurting yourself, or that you’d be better off dead?</p><div class="seg big" role="group" aria-label="Answer"><button ${ap(c.safety===false)} data-a="ci" data-k="safety" data-v="0">No</button><button ${ap(c.safety===true)} data-a="ci" data-k="safety" data-v="1">Yes</button></div>
     <p class="small muted" style="margin-top:var(--sp-4)">This can be a side effect early on. “Yes” connects you with support right away.</p>`; }
  const last=i===cards.length-1;
  const foot=`<button class="btn block" data-a="${last?'ciSave':k==='mood'?'ciMoodNext':'ciNext'}" ${ok?'':'disabled'}>${last?ic('check')+'Save check-in':k==='mood'?'That’s me'+ic('arrow-right'):'Next'+ic('arrow-right')}</button>`;
  return flowFrame({back:i?'ciBack':'ciClose',backLabel:i?'Back':'Close',i,total:cards.length,title,sub,body,foot});
}

/* ============================================================
   Journey
   ============================================================ */
function curveSVG(){
  const W=340,H=190,px=14,py=20,cw=W-px-10,ch=H-py-34,X=d=>px+(d/42)*cw,Y=v=>py+ch-v*ch;
  const fxC=d=>.15+.75*Math.exp(-d/10), bC=d=>.1+.75/(1+Math.exp(-(d-22)/5));
  let a='',b='';for(let d=0;d<=42;d++){a+=(d?'L':'M')+X(d).toFixed(1)+' '+Y(fxC(d)).toFixed(1);b+=(d?'L':'M')+X(d).toFixed(1)+' '+Y(bC(d)).toFixed(1);}
  let dots='',n=0;logsArr().forEach(l=>{const d=diffDays(D.startDate,l.date)+1;if(d<1||d>42)return;n++;dots+=`<circle cx="${X(d).toFixed(1)}" cy="${Y(Math.min(1,l.fx.length/3)).toFixed(1)}" r="3.2" fill="var(--c-fx)" opacity=".85"/><circle cx="${X(d).toFixed(1)}" cy="${Y((l.mood-1)/4).toFixed(1)}" r="3.4" fill="var(--c-mood)"/>`;});
  const grid=[0,7,14,21,28,35,42].map(d=>`<line x1="${X(d)}" x2="${X(d)}" y1="${py}" y2="${py+ch}" stroke="var(--c-grid)" stroke-width="1"/>`).join('')+`<line x1="${px}" x2="${X(42)}" y1="${py+ch}" y2="${py+ch}" stroke="var(--c-grid)"/>`+[1,2,3,4,5,6].map(i=>`<text x="${X(i*7-3.5)}" y="${H-12}" text-anchor="middle">Wk ${i}</text>`).join('');
  const dn=Math.min(42,dayNum());
  return `<svg class="chart" viewBox="0 0 ${W} ${H}" role="img" aria-label="Chart of your mood and side effects across six weeks, with ${n} check-ins plotted against the usual pattern.">${grid}<path d="${a}" fill="none" stroke="var(--c-fx)" stroke-width="1.75" stroke-dasharray="5 4" opacity=".75"/><path d="${b}" fill="none" stroke="var(--c-mood)" stroke-width="1.75" stroke-dasharray="5 4" opacity=".75"/>${dots}<line x1="${X(dn)}" x2="${X(dn)}" y1="${py-4}" y2="${py+ch}" stroke="var(--text)" stroke-width="1.25" opacity=".55"/><text x="${clamp(X(dn),24,W-24)}" y="${py-8}" text-anchor="middle" style="fill:var(--text);font-weight:700">today</text></svg>
   <div class="legend"><span><i style="background:var(--c-mood)"></i>Your mood</span><span><i style="background:var(--c-fx)"></i>Your side effects</span><span style="color:var(--text-2)"><i class="line"></i>Usual pattern</span></div>`;
}
function moodStrip(){
  const days=[];for(let i=6;i>=0;i--) days.push(addDays(todayKey(),-i));
  return `<div class="mood-row" role="list" aria-label="Mood over the last 7 days">${days.map(dk=>{const l=D.logs[dk];const wd=parseKey(dk).toLocaleDateString('en-US',{weekday:'short'});return l?`<div class="mood-day" role="listitem">${blob(l.mood,`${wd}: ${MOOD[l.mood-1].w}`)}<span class="d">${wd[0]}</span></div>`:`<div class="mood-day empty" role="listitem" aria-label="${wd}: no check-in"><span class="dot" aria-hidden="true"></span><span class="d" aria-hidden="true">${wd[0]}</span></div>`;}).join('')}</div>`;
}
function insightCard(i){ const pct=v=>i.mood?(v*5).toFixed(1):Math.round(v*100)+'%';
  return `<article class="card insight"><div class="row" style="margin-bottom:var(--sp-4)"><span class="ico-badge">${ic(i.ico)}</span><h3>${i.title}</h3></div>${[i.a,i.b].map((x,k)=>`<div class="cmp"><span class="muted">${x[0]}</span><div class="bar"><span style="width:${Math.max(4,x[1]*100)}%;background:${k?'var(--text-3)':'var(--c-mood)'}"></span></div><b>${pct(x[1])}</b></div>`).join('')}${i.act?`<p class="act">${ic('arrow-right','ic-sm')}${i.act}</p>`:''}</article>`; }
function renderJourney(){ const w=weekOf(dayNum()), W=WEEKS[Math.min(5,w-1)], dn=dayNum(), L=logsArr(), life=insights().filter(i=>i.kind==='life');
  const within=((dn-1)%7+1)/7*100;
  const head=`<header class="page-head"><div class="grow"><p class="eyebrow">Your journey${D.sample?' · <span class="badge sample">Sample data</span>':''}</p><h1>Week ${Math.min(6,w)} of 6</h1><p class="lede">${W.t}</p>
    <div class="week-track" aria-hidden="true">${[1,2,3,4,5,6].map(i=>`<span class="${i<w?'done':i===w?'now':''}" style="${i===w?`--p:${w>6?100:within}%`:''}"></span>`).join('')}</div><div class="week-track-labels" aria-hidden="true">${[1,2,3,4,5,6].map(i=>`<span class="${i===Math.min(6,w)?'now':''}">Wk ${i}</span>`).join('')}</div></div></header>`;
  const recorded=`<span class="badge sec">${ic('pencil')}From your check-ins</span>`;
  let main=L.length?sec('Last 7 days',`<div class="card">${moodStrip()}</div>`,{eyebrow:recorded}):sec('Your check-ins',`<div class="panel center stack" style="align-items:center">${ill('sprout','md')}<p class="muted small" style="max-width:22rem">Check in each day and your mood and side effects will appear here.</p><button class="btn sm" data-a="startCi">Check in</button></div>`,{eyebrow:recorded});
  main+=sec('Mood and side effects',`<div class="card">${curveSVG()}</div>`,{note:'Dots are your check-ins. Dashed lines show the usual pattern for comparison.'});
  if(life.length) main+=sec('Patterns we noticed',`<div class="stack">${life.map(insightCard).join('')}</div>`,{eyebrow:recorded});
  const guide=`<span class="badge plain">${ic('book')}General guide</span>`;
  const side=sec('What to expect',`<div class="card tight">${WEEKS.map((X,i)=>{const st=i+1<w?'done':i+1===w?'now':'next';return `<details class="disclose" ${i+1===Math.min(6,w)?'open':''}><summary><span class="week-status ${st}" aria-hidden="true">${ic(st==='done'?'check':st==='now'?'pin':'circle-dashed')}</span><span class="grow"><span class="tiny muted" style="display:block">Week ${i+1}${st==='now'?' · now':''}</span><b>${X.t}</b></span>${ic('chevron-down','chev')}</summary><div class="disclose-body"><div class="wk-grid"><div><p class="eyebrow">Side effects</p><p>${X.e}</p></div><div><p class="eyebrow">Benefits</p><p>${X.b}</p></div></div></div></details>`;}).join('')}</div>`,{eyebrow:guide,note:'What many people experience. Everyone’s path differs.'});
  return head+`<div class="cols"><div class="col">${main}</div><div class="col col-side">${side}</div></div>`; }

/* ============================================================
   Routine
   ============================================================ */
function clockSVG(){
  const p=D.profile,C=60,R=46,pt=(m,r)=>{const a=(m/1440)*2*Math.PI-Math.PI/2;return [C+r*Math.cos(a),C+r*Math.sin(a)]};
  const arc=(m1,m2,r)=>{if(m2<m1)m2+=1440;const [x1,y1]=pt(m1,r),[x2,y2]=pt(m2,r);return `M${x1} ${y1} A${r} ${r} 0 ${(m2-m1)>720?1:0} 1 ${x2} ${y2}`;};
  let dots='';logsArr().filter(l=>l.taken).forEach(l=>{const [x,y]=pt(tmin(l.time),R-14);dots+=`<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="2.6" fill="${l.food?'var(--c-dose)':'var(--c-dose-nf)'}" opacity=".85"/>`;});
  const plan=D.plan?pt(tmin(D.plan.time),R):null;
  const lbl=[['12a',0],['6a',360],['12p',720],['6p',1080]].map(([t,m])=>{const [x,y]=pt(m,R+12);return `<text x="${x}" y="${y+3}" font-size="8" text-anchor="middle">${t}</text>`}).join('');
  return `<svg class="clock" viewBox="-10 -10 140 140" role="img" aria-label="24-hour clock showing sleep, meals${D.plan?' and your dose time, '+fmtT(D.plan.time):''}"><circle cx="${C}" cy="${C}" r="${R}" fill="none" stroke="var(--c-bar)" stroke-width="8"/><path d="${arc(tmin(p.bed),tmin(p.wake),R)}" fill="none" stroke="var(--c-sleep)" stroke-width="8" stroke-linecap="round"/>${p.meals.map(t=>{const [x1,y1]=pt(tmin(t),R-6),[x2,y2]=pt(tmin(t),R+6);return `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="var(--c-meal)" stroke-width="3.5" stroke-linecap="round"/>`}).join('')}${dots}${plan?`<circle cx="${plan[0]}" cy="${plan[1]}" r="7" fill="var(--pri)" stroke="var(--surface)" stroke-width="2.5"/>`:''}${lbl}</svg>`;
}
function renderRoutine(){
  const g=drug(), ur=usingRight(), ix=interactions(), m=D.med, p=D.profile;
  if(!g) return emptyState(ill('pill','xl'),'No medication yet','',`<button class="btn" data-a="addMed">${ic('plus')}Add your medication</button>`);
  const head=`<header class="page-head"><div><p class="eyebrow">Your routine</p><h1>${esc(g.name)} ${m.mg?fmtMg(m.mg):''}</h1><p class="muted">${esc(g.brand||'')}${D.startDate?` · since ${fmtDay(D.startDate)}`:''}</p></div><div class="head-side"><button class="btn quiet sm" data-a="sheet" data-v="plan">${ic('clock')}Edit routine</button></div></header>`;
  let main=`<section class="card" aria-labelledby="time-h"><div class="time-hero">${clockSVG()}<div class="grow"><p class="eyebrow" id="time-h">Your dose time</p><div class="display">${D.plan?fmtT(D.plan.time):'Not set'}</div><p class="muted">${D.plan?esc(cap1(D.plan.label.toLowerCase())):''}${D.plan&&D.plan.food&&!/^with/i.test(D.plan.label)?' · with food':''}</p><button class="btn tonal sm" data-a="sheet" data-v="plan" style="margin-top:var(--sp-3)">Change time</button></div></div>
    <div class="legend"><span><i style="background:var(--c-sleep)"></i>Sleep</span><span><i style="background:var(--c-meal)"></i>Meals</span><span><i style="background:var(--c-dose)"></i>Dose with food</span><span><i style="background:var(--c-dose-nf)"></i>Dose, no food</span></div></section>`;
  main+=sec('Am I taking it right?',`<div class="card tight">${ur?`<ul class="list no-top">${ur.map(x=>`<li class="check-row"><span class="ico-badge sm plain">${ic(x.ico)}</span><span class="grow">${x.t}</span><span class="state ${x.ok?'ok':'no'}" role="img" aria-label="${x.ok?'On track':'Worth a look'}">${ic(x.ok?'check':'alert')}</span></li>`).join('')}</ul>`:'<p class="small muted">Check in for a few days to see this.</p>'}</div>`);
  const how=insights().filter(i=>i.kind==='how'); if(how.length) main+=`<div class="stack">${how.map(insightCard).join('')}</div>`;
  main+=sec('Other medications',`<div class="card">${otherMedsEditor()}${ix.length?`<div style="margin-top:var(--sp-5)">${ix.map(i=>`<div class="ix ${i.sev}">${ic(i.sev==='avoid'?'octagon':i.sev==='caution'?'alert':'info')}<div><b>${esc(i.with)}</b> <span class="tag ${i.sev==='avoid'?'t-ask':i.sev==='caution'?'t-how':'t-sick'}">${i.sev==='avoid'?'Avoid':i.sev==='caution'?'Caution':'Note'}</span><p class="small muted">${i.why}</p></div></div>`).join('')}</div>`:''}<p class="privacy" style="margin-top:var(--sp-4)">${ic('info')}Not a complete check. Show your list to your pharmacist.</p></div>`);
  const dets=[['Strength',m.mg?fmtMg(m.mg):''],['Directions',m.directions],['Quantity',m.qty],['Refills',m.refills],['Prescriber',m.prescriber],['Pharmacy',m.pharmacy],['Started',D.startDate?fmtDay(D.startDate):'']].filter(x=>x[1]);
  let side=sec('Medication details',`<div class="card tight"><dl class="kv">${dets.map(([a,b])=>`<dt>${a}</dt><dd>${esc(b)}</dd>`).join('')}</dl><button class="link" data-a="addMed" style="margin-top:var(--sp-2)">${ic('refresh','ic-sm')}Change medication</button></div>`);
  side+=sec('Good to know',`<div class="card tight"><ul class="list no-top"><li><span class="ico-badge sm">${ic('utensils')}</span><span>${g.food==='with'?'Take with food.':'With or without food.'}</span></li><li><span class="ico-badge sm">${ic('glass-off')}</span><span>Skip alcohol.</span></li><li><span class="ico-badge sm caution">${ic('octagon')}</span><span>Don’t stop suddenly.</span></li>${g.extra?`<li class="top"><span class="ico-badge sm sec">${ic('info')}</span><span>${g.extra}</span></li>`:''}</ul></div>`);
  side+=sec('Your day',`<div class="card tight"><ul class="list no-top"><li>${ic('sun')}<span class="grow">Up around</span><b>${fmtT(p.wake)}</b></li><li>${ic('moon')}<span class="grow">Asleep around</span><b>${fmtT(p.bed)}</b></li><li>${ic('utensils')}<span class="grow">Meals</span><b>${p.meals.length} a day</b></li></ul><button class="link" data-a="settings" style="margin-top:var(--sp-2)">${ic('settings','ic-sm')}Edit in settings</button></div>`,{note:'Your time is ranked from these.'});
  return head+`<div class="cols"><div class="col">${main}</div><div class="col col-side">${side}</div></div>`;
}

/* ============================================================
   Circle (patient)
   ============================================================ */
function renderCircle(){
  if(!D.circle) return emptyState(ill('people','xl'),'Bring your people along','Gentle nudges for them. Your check-ins stay private.',`<button class="btn secondary" data-a="createCircle">${ic('users')}Create my circle</button>`);
  const c=D.circle, mem=c.members||[], st=c.status, hs=helpedStats();
  const kinds={think:['heart','Thinking of you'],message:['message','Messages'],plan:['calendar','Plans'],claim:['hand','Help']};
  const head=`<header class="page-head"><div><p class="eyebrow">Your circle</p><h1>Your people</h1><p class="muted">${mem.length?`${mem.length} ${mem.length===1?'person':'people'} in your corner`:'Invite someone to get started'}</p></div></header>`;
  let main=sec('Send a quick update',`<div class="tiles">${[['rough','cloud-rain','Rough day'],['company','coffee','Want company'],['good','sun','Good day']].map(([k,e,l])=>`<button class="tile" ${ap(st&&st.k===k&&Date.now()-st.at<36*36e5)} data-a="status" data-v="${k}">${ic(e)}${l}${tick}</button>`).join('')}</div>${dayNum()>=14?`<button class="btn quiet block" style="margin-top:var(--sp-3)" data-a="milestone">${ic('award')}Share: ${Math.floor(dayNum()/7)} weeks done</button>`:''}`,{note:'Sends a text to everyone in your circle.'});
  const asks=(c.asks||[]).slice(-3).reverse();
  main+=sec('Ask for help',`<div class="inline-add"><label class="sr-only" for="askIn">What do you need?</label><input type="text" id="askIn" placeholder="e.g. Can someone pick up groceries?" maxlength="80"><button class="btn" data-a="askCustom">${ic('send')}Ask</button></div>${asks.length?`<ul class="list" style="margin-top:var(--sp-4)">${asks.map(a=>`<li><span class="ico-badge sm ${a.claimedBy?'ok':'plain'}">${ic(a.claimedBy?'check':'clock')}</span><span class="grow"><span class="small">${esc(a.text)}</span><span class="tiny muted" style="display:block">${a.claimedBy?`${esc(a.claimedBy)} has it`:'Waiting'} · ${ago(a.at)}</span></span></li>`).join('')}</ul>`:''}`);
  main+=sec('Recent activity',`<div class="card tight">${D.received.length?`<ul class="list no-top feed">${D.received.slice(0,8).map(e=>`<li class="top"><span class="ico-badge sm sec">${ic(e.type==='think'?'heart':e.type==='plan'?'calendar':e.type==='claim'?'hand':'message')}</span><div class="grow"><p><span class="who">${esc(e.name)}</span> <span class="when">· ${ago(e.at)}</span></p><p class="msg">${e.type==='think'?'Thinking of you.':esc(e.text)}</p>
     ${D.helped[e.id]?`<span class="tiny muted row" style="gap:.3rem;margin-top:.2rem">${ic(D.helped[e.id]==='yes'?'heart':'check','ic-sm')}${D.helped[e.id]==='yes'?'Helped':'Noted'}</span>`:`<div class="actions"><button class="link" data-a="helped" data-id="${e.id}" data-v="yes">That helped</button><button class="link muted" data-a="helped" data-id="${e.id}" data-v="no">Not really</button></div>`}</div></li>`).join('')}</ul>`:`<div class="row top" style="padding:var(--sp-2) 0">${ic('message','ic-md faint')}<p class="small muted">When someone reaches out, it shows here. Their texts include a link: tap it to add it.</p></div>`}</div>`);
  if(Object.keys(hs).length) main+=sec('What helps you most',`<div class="card">${Object.keys(hs).map(k=>`<div class="cmp" style="grid-template-columns:minmax(7.5rem,auto) 1fr 2.5rem"><span class="small row" style="gap:.4rem">${ic((kinds[k]||['sparkle'])[0],'ic-sm')}${(kinds[k]||[0,k])[1]}</span><div class="bar"><span style="width:${hs[k].y/(hs[k].y+hs[k].n)*100}%;background:var(--sec)"></span></div><b class="small">${hs[k].y}/${hs[k].y+hs[k].n}</b></div>`).join('')}<p class="privacy" style="margin-top:var(--sp-4)">${ic('lock')}Shapes their nudges. They never see these answers.</p></div>`);
  let side=sec('Members',`${mem.length?`<div class="card tight"><ul class="list no-top">${mem.map(m=>{const cp=CAPS.find(x=>x[0]===m.cap)||CAPS[1];return `<li><div class="avatar">${esc((m.name||'?')[0])}</div><div class="grow"><p class="list-title">${esc(m.name)}</p><p class="list-sub row" style="gap:.35rem">${m.rel?esc(m.rel)+' · ':''}${ic(cp[1],'ic-sm')}${cp[2]}${m.pausedUntil&&m.pausedUntil>=todayKey()?' · on a break':''}</p></div><button class="btn ghost sm" data-a="preview" data-v="${m.id}" aria-label="Preview ${esc(m.name)}’s view">${ic('eye')}Their view</button></li>`;}).join('')}</ul></div>`:''}<div style="margin-top:var(--sp-3)">${inviteBox()}</div>`);
  side+=sec('How I like support',`<div class="card tight"><div class="chips">${D.supportCard.map(x=>{const pr=SUPPORT_PRESETS.find(p=>p[0]===x);return `<span class="chip tag">${ic(pr?pr[1]:'sparkle')}${esc(x)}</span>`;}).join('')||'<span class="small muted">Not set yet</span>'}</div><button class="link" data-a="sheet" data-v="scard" style="margin-top:var(--sp-2)">${ic('pencil','ic-sm')}Edit</button></div>`);
  side+=`<p class="privacy">${ic('shield')}They see your week, support card, hobbies and updates you send. Never your check-ins.</p>`;
  return head+`<div class="cols"><div class="col">${main}</div><div class="col col-side">${side}</div></div>`;
}

/* ============================================================
   Supporter
   ============================================================ */
function renderSupporterHome(){
  if(!D.supporting.length) return emptyState(ill('mail','xl'),'Waiting for an invite','Open the invite link your friend texted you. It brings you straight here.');
  const code=S.flags.supCode&&D.supporting.some(s=>s.code===S.flags.supCode)?S.flags.supCode:D.supporting[0].code, sup=D.supporting.find(s=>s.code===code);
  return (D.supporting.length>1?`<div class="chips" role="group" aria-label="Who you support" style="margin-bottom:var(--sp-6)">${D.supporting.map(s=>`<button class="chip" ${ap(s.code===code)} data-a="supCode" data-v="${s.code}">${esc(s.snap.o)}</button>`).join('')}</div>`:'')+supporterView(sup,false);
}
function supporterView(sup,preview){
  const s=sup.snap, name=esc(s.o||'your friend'), w=s.w||0, N=nudgeFor(sup), {say,skip}=sayList(s);
  const st=s.st&&Date.now()-s.st.at<36*36e5?s.st:null, stT={rough:['cloud-rain','Rough day, no talking needed'],company:['coffee','Could use company'],good:['sun','Good day!']};
  let head=`${preview?`<div class="notice info" style="margin-bottom:var(--sp-5)">${ic('eye')}<p>What <b>${esc(sup.me.name||'they')}</b> sees</p></div>`:''}
   <header class="page-head"><div class="row top" style="gap:var(--sp-4)"><div class="avatar lg pri">${name[0]||'?'}</div><div><p class="eyebrow">With ${name}</p><h1>${w?`Week ${Math.min(6,w)}`:'Just starting'}</h1>${w?`<p class="muted" style="max-width:34rem;margin-top:var(--sp-1)">${SUP_WEEK[Math.min(5,w-1)](name)}</p>`:''}</div></div></header>`;
  let main='';
  if(st) main+=`<div class="notice info">${ic(stT[st.k][0])}<p><b>${name}:</b> ${stT[st.k][1]} <span class="muted">· ${ago(st.at)}</span></p></div>`;
  if(N.paused) main+=`<div class="notice">${ic('pause')}<div class="grow"><p>You’re on a break until ${fmtDay(sup.me.pausedUntil)}. Others have it covered.</p>${preview?'':`<div class="btn-row"><button class="btn sm quiet" data-a="unpause" data-v="${sup.code}">I’m back</button></div>`}</div></div>`;
  N.items.forEach((n,i)=>{ const id=sup.code+'-'+i, urgent=n.tone==='danger';
    main+=`<article class="card nudge ${urgent?'urgent':''}"><div class="nudge-head"><span class="ico-badge ${urgent?'urgent':n.tone==='warn'?'warn':'sec'}">${ic(n.ico)}</span><div><h3>${n.title}</h3><p class="small muted" style="margin-top:.2rem">${n.body}</p></div></div>
     ${n.kind==='think'?'':`<div><label class="sr-only" for="msg-${id}">Message to ${name}</label><textarea id="msg-${id}">${esc(n.msg)}</textarea></div>${n.kind==='plan'?`<div class="chips" role="group" aria-label="When">${[['today','Today'],['tomorrow','Tomorrow'],['weekend','This weekend']].map(([v,l])=>`<button class="chip" ${ap(S.flags['when-'+id]===v)} data-a="when" data-id="${id}" data-v="${v}">${l}</button>`).join('')}</div>`:''}
     <button class="btn ${urgent?'danger':'secondary'}" data-a="sendMsg" data-v="${sup.code}" data-id="${id}" data-kind="${n.kind}" ${preview?'disabled':''}>${ic('message')}Text ${name}</button>`}
     ${urgent?`<p class="small row" style="gap:.5rem">${ic('phone','ic-sm')}<span><b>988</b> Suicide & Crisis Lifeline · <a href="tel:988">call</a> or <a href="sms:988">text</a></span></p>`:''}</article>`; });
  if(N.quiet&&!N.paused) main+=`<div class="notice ok">${ic('leaf')}<p><b>Nothing needed today.</b> ${N.prefThink?'A quick “thinking of you” tends to land well.':'A quick “thinking of you” is always welcome.'}</p></div>`;
  main+=`<button class="btn secondary block" data-a="think" data-v="${sup.code}" ${preview?'disabled':''}>${ic('heart')}Send “thinking of you”</button>`;
  (s.ak||[]).forEach(a=>{main+=`<div class="notice warn">${ic('hand')}<div class="grow"><p><b>${name} asked:</b> ${esc(a.text)}</p><div class="btn-row"><button class="btn sm" data-a="claim" data-v="${sup.code}" data-id="${a.id}" ${preview?'disabled':''}>${ic('check')}I’ve got it</button></div></div></div>`;});
  let side='';
  if(s.sc&&s.sc.length) side+=sec(`How ${name} likes support`,`<div class="chips">${s.sc.map(x=>{const pr=SUPPORT_PRESETS.find(p=>p[0]===x);return `<span class="chip tag">${ic(pr?pr[1]:'sparkle')}${esc(x)}</span>`;}).join('')}</div>${s.h&&s.h.length?`<p class="small muted" style="margin-top:var(--sp-3)">Enjoys: ${s.h.map(esc).join(', ')}</p>`:''}`,{hid:'likes'+(preview?'p':'')});
  side+=sec('Say and skip',`<div class="card say-skip"><div class="say"><p class="eyebrow" style="color:var(--ok-text);margin-bottom:var(--sp-2)">Say</p><ul>${say.map(x=>`<li>${ic('check')}<span>${x}</span></li>`).join('')}</ul></div><div class="skip-l"><p class="eyebrow" style="color:var(--caution-text);margin-bottom:var(--sp-2)">Skip</p><ul>${skip.map(x=>`<li>${ic('x')}<span>${x}</span></li>`).join('')}</ul></div></div>`,{hid:'say'+(preview?'p':'')});
  side+=`<div class="notice">${ic('heart')}<p><b>Supporting someone is hard. You’re doing well.</b> You’re not their safety net: if worried, call or text 988 together.</p></div>`;
  if(!preview&&!N.paused) side+=`<div class="btn-row"><button class="btn quiet sm" data-a="pause" data-v="${sup.code}">${ic('pause')}Not this week</button><button class="btn quiet sm" data-a="capSheet" data-v="${sup.code}">${ic('settings')}How much I help</button></div>`;
  if(!preview) side+=`<p class="tiny muted">Updated ${ago(s.ts)}. New updates arrive as links in ${name}’s texts.</p>`;
  return head+(preview?`<div class="stack-lg">${main}${side}</div>`:`<div class="cols"><div class="col" style="gap:var(--sp-4)">${main}</div><div class="col col-side">${side}</div></div>`);
}
function renderJoin(){
  const j=S.joinDraft, s=j.snap, steps=['hello','rel','cap','primer'], k=steps[j.step], name=esc(s.o);
  let title='',body='',ok=true,next='Next',art='';
  if(k==='hello'){art=ill('people','lg');title=`${name} wants you in their corner`;body=`<p class="muted center">They’re starting a new medication. You’ll get a few gentle, well-timed nudges. No account needed.</p>${!D.name?`<div class="field" style="margin-top:var(--sp-5)"><label class="label" for="j-name">Your first name</label><input id="j-name" type="text" data-a="nameIn" value="${esc(D.name)}" autocomplete="given-name"></div><div class="field"><label class="label" for="j-phone">Your number <span class="opt-note">(optional)</span></label><input id="j-phone" type="tel" data-a="phoneIn" value="${esc(D.phone)}" autocomplete="tel"></div>`:''}`;}
  if(k==='rel'){art=ill('heart','lg');title=`How do you know ${name}?`;body=`<div class="chips" style="justify-content:center">${RELATIONS.map(([r,e])=>`<button class="chip" ${ap(j.rel===r)} data-a="jrel" data-v="${r}">${ic(e)}${r}</button>`).join('')}</div>`;ok=!!j.rel;}
  if(k==='cap'){art=ill('star','lg');title='How much can you give?';body=`<div class="opts" role="radiogroup" aria-label="How much you can give">${CAPS.map(([v,e,t,d])=>`<button class="opt has-tick" role="radio" aria-checked="${j.cap===v}" data-a="jcap" data-v="${v}"><span class="ico-badge">${ic(e)}</span><span><span class="opt-title">${t}</span><span class="opt-desc">${d}</span></span>${tick}</button>`).join('')}</div>
    <p class="label" style="margin-top:var(--sp-5)">Happy to help with</p><div class="chips">${TASKS.map(([t,e])=>`<button class="chip" ${ap(j.tasks.includes(t))} data-a="jtask" data-v="${t}">${ic(e)}${t}</button>`).join('')}</div><p class="hint">Change or pause anytime.</p>`;}
  if(k==='primer'){art=ill('leaf','lg');title='The 30-second primer';body=`<div class="card tight"><ul class="list no-top"><li><span class="ico-badge sm">${ic('trend')}</span><span>Weeks 1–2 are often hardest: side effects before benefits.</span></li><li><span class="ico-badge sm sec">${ic('heart')}</span><span>Small, low-pressure contact. Plans over questions.</span></li><li><span class="ico-badge sm caution">${ic('ban')}</span><span>Skip “did you take your meds?”</span></li></ul></div><div class="notice urgent" style="margin-top:var(--sp-3)">${ic('phone')}<p>You’re not their safety net. Worried? Call or text <b>988</b> together.</p></div>`;next='Join and let them know';}
  return flowFrame({back:'joinBack',backLabel:j.step?'Back':'Cancel',i:j.step,total:4,art,title,body,center:true,foot:`<button class="btn block" data-a="joinNext" ${ok?'':'disabled'}>${next}${ic('arrow-right')}</button>`});
}

/* ============================================================
   Report
   ============================================================ */
function reportData(){
  const g=drug(), L=logsArr(), t=triage(), w=weekOf(dayNum()), ins=insights(), tk=L.filter(l=>l.taken).length, ix=interactions().filter(i=>i.sev!=='note');
  const wk=[];for(let i=1;i<=Math.min(6,w);i++){const a=L.filter(l=>weekOf(diffDays(D.startDate,l.date)+1)===i);if(a.length)wk.push({w:i,fx:a.reduce((s,l)=>s+l.fx.length,0)/a.length,mood:a.reduce((s,l)=>s+l.mood,0)/a.length,sick:a.filter(l=>l.sick).length});}
  const recent=[...new Set(L.slice(-5).flatMap(l=>l.fx))], sick=L.slice(-7).filter(l=>l.sick).length;
  const script=`Hi, I’m calling about ${D.name||'[name]'}. I started ${g.name}${D.med.mg?' '+fmtMg(D.med.mg):''} on ${fmtDay(D.startDate)}${D.med.prescriber?', prescribed by '+D.med.prescriber:''}. I’m on day ${dayNum()}. ${recent.length?'Lately I’ve had '+recent.join(', ').toLowerCase()+'. ':''}${sick?`I’ve also been sick ${sick} of the last 7 days. `:''}${t.lvl==='orange'?`Side effects don’t seem to be easing by week ${w}. `:''}I’ve taken ${tk} of ${L.length} doses${D.plan?', usually around '+fmtT(D.plan.time):''}.${D.otherMeds.length?' I also take '+D.otherMeds.join(', ')+'.':''} Is this expected, or should anything change?`;
  return {g,L,t,w,ins,tk,ix,wk,script};
}
function summaryText(r){
  const lines=[`DoseWise summary${D.sample?' (includes sample data)':''}`,`${r.g.name}${D.med.mg?' '+fmtMg(D.med.mg):''} · started ${fmtDay(D.startDate)} · day ${dayNum()}`,`Doses taken: ${r.tk} of ${r.L.length}${D.plan?' · usual time '+fmtT(D.plan.time):''}`,`Status: ${r.t.label}${r.t.msg?' – '+r.t.msg:''}`];
  if(r.wk.length){lines.push('','Week by week:');r.wk.forEach(x=>lines.push(`  Week ${x.w}: ${x.fx.toFixed(1)} side effects/day, mood ${x.mood.toFixed(1)}/5${x.sick?`, sick ${x.sick} day${x.sick>1?'s':''}`:''}`));}
  if(r.ins.length||r.ix.length){lines.push('','Worth mentioning:');r.ins.forEach(i=>lines.push('  - '+i.title));r.ix.forEach(i=>lines.push('  - Also takes '+i.with));}
  if(D.otherMeds.length) lines.push('','Other medications: '+D.otherMeds.join(', '));
  return lines.join('\n');
}
function renderReport(){
  const r=reportData(), {g,L,t,w,ins,tk,ix,wk,script}=r, left=pillsLeft();
  const head=`<header class="page-head"><div><p class="eyebrow">Prescriber summary${D.sample?' · <span class="badge sample">Includes sample data</span>':''}</p><h1>For your prescriber</h1><p class="muted">${esc(g.name)} ${D.med.mg?fmtMg(D.med.mg):''} · since ${fmtDay(D.startDate)}</p></div><div class="head-side no-print"><button class="btn quiet sm" data-a="print">${ic('printer')}Print</button></div></header>`;
  const stats=`<div class="report-stats"><div class="stat"><p class="eyebrow">Doses taken</p><div class="num-display">${tk}<span class="muted" style="font-size:.6em">/${L.length}</span></div><p class="stat-sub">${D.plan?'Usually around '+fmtT(D.plan.time):'Logged days'}</p></div>
    <div class="stat"><p class="eyebrow">Status</p><div style="margin-top:.35rem"><span class="status s-${t.lvl}"><span class="dot"></span>${t.label}</span></div><p class="stat-sub" style="margin-top:.5rem">${t.msg||'Nothing flagged'}</p></div>
    <div class="stat"><p class="eyebrow">Treatment</p><div class="num-display">Day ${dayNum()}</div><p class="stat-sub">Week ${Math.min(6,w)} of 6${left!==null?` · ~${left} doses left`:''}</p></div></div>`;
  let main=stats;
  main+=wk.length?sec('Week by week',`<div class="card"><table class="wk-table"><thead><tr><th scope="col">Week</th><th scope="col">Side effects / day</th><th scope="col">Mood (1–5)</th></tr></thead><tbody>${wk.map(x=>`<tr><td>Wk ${x.w}</td><td><div class="cell"><div class="bar"><span style="width:${Math.min(100,x.fx/3*100)}%;background:var(--c-fx)"></span></div><b>${x.fx.toFixed(1)}</b></div>${x.sick?`<span class="tiny muted row" style="gap:.25rem;margin-top:.2rem">${ic('thermometer','ic-sm')}Sick ${x.sick} day${x.sick>1?'s':''}</span>`:''}</td><td><div class="cell"><div class="bar"><span style="width:${x.mood/5*100}%;background:var(--c-mood)"></span></div><b>${x.mood.toFixed(1)}</b></div></td></tr>`).join('')}</tbody></table></div>`)
    :sec('Week by week',`<div class="panel"><p class="small muted">Check-ins you log will be summarised here by week.</p></div>`);
  let side=sec('What to say',`<div class="card"><blockquote class="script">“${esc(script)}”</blockquote><div class="btn-row no-print" style="margin-top:var(--sp-5)"><button class="btn sm" data-a="copy" data-v="${esc(script)}">${ic('copy')}Copy script</button><button class="btn sm quiet" data-a="copySummary">${ic('report')}Copy full summary</button></div></div>`,{eyebrow:'Phone script'});
  if(ins.length||ix.length) side+=sec('Worth mentioning',`<div class="card tight"><ul class="list no-top">${ins.map(i=>`<li><span class="ico-badge sm plain">${ic(i.ico)}</span><span>${i.title}</span></li>`).join('')}${ix.map(i=>`<li><span class="ico-badge sm warn">${ic('alert')}</span><span>Also takes ${esc(i.with)}</span></li>`).join('')}</ul></div>`);
  if(D.otherMeds.length) side+=sec('Other medications',`<div class="chips">${D.otherMeds.map(m=>`<span class="chip tag">${ic('pill')}${esc(m)}</span>`).join('')}</div>`);
  return head+`<div class="cols"><div class="col">${main}</div><div class="col col-side">${side}</div></div><p class="tiny muted" style="margin-top:var(--sp-7)">Made from check-ins on this device. A conversation starter, not a diagnosis.</p>`;
}

/* ============================================================
   Layers: sheets, urgent support, toast
   ============================================================ */
let sheetOpener=null, sheetKey=null;
const ovKey=o=>!o?null:typeof o==='string'?o:o.kind+':'+(o.id||o.code||'');
function sheetContent(o){
  const done=`<button class="btn" data-a="closeOverlay">Done</button>`;
  if(o==='plan') return {title:'Choose your time',body:routinePicker(),foot:done};
  if(o==='scard') return {title:'How I like support',body:`<p class="muted small" style="margin-bottom:var(--sp-4)">Your circle sees this.</p>${iconChips('scard',SUPPORT_PRESETS,D.supportCard,'In your own words…')}`,foot:done};
  if(o.kind==='share') return {title:'Send it',body:`<p class="small muted">Text this to them:</p><div class="share-text">${esc(o.text)}</div>`,foot:`<a class="btn" href="${esc(o.sms)}">${ic('message')}Open Messages</a><button class="btn quiet" data-a="copy" data-v="${esc(o.text)}">${ic('copy')}Copy</button><button class="btn ghost" data-a="closeOverlay">Done</button>`};
  if(o.kind==='preview'){ const m=(D.circle.members||[]).find(x=>x.id===o.id)||{}; const fake={code:D.circle.code,snap:snapshot(),me:{id:m.id,name:m.name,cap:m.cap,tasks:m.tasks||[],pausedUntil:m.pausedUntil}}; const saved=D.myId; D.myId=m.id; const v=supporterView(fake,true); D.myId=saved; return {title:'Their view',body:v,foot:`<button class="btn" data-a="closeOverlay">Close</button>`,wide:true}; }
  if(o.kind==='cap'){ const sup=D.supporting.find(x=>x.code===o.code); return {title:'How much can you give?',body:`<div class="opts" role="radiogroup" aria-label="How much you can give">${CAPS.map(([v,e,t,d])=>`<button class="opt has-tick" role="radio" aria-checked="${sup.me.cap===v}" data-a="capSet" data-c="${o.code}" data-v="${v}"><span class="ico-badge">${ic(e)}</span><span><span class="opt-title">${t}</span><span class="opt-desc">${d}</span></span>${tick}</button>`).join('')}</div>`,foot:done}; }
  if(o==='settings') return {title:'Settings',body:settingsBody(),foot:done,wide:true};
  if(o==='reset') return {title:'Start over?',body:`<div class="notice urgent">${ic('alert')}<p>This clears everything on this device: your medication, check-ins and circle. It can’t be undone.</p></div>`,foot:`<button class="btn danger" data-a="doReset">${ic('trash')}Yes, start over</button><button class="btn quiet" data-a="closeOverlay">Cancel</button>`};
  return {title:'',body:''};
}
function renderLayer(){
  const layer=$('#layer'), o=S.overlay, key=ovKey(o);
  let scrim=layer.querySelector('.scrim:not(.closing)');
  if(o){
    const c=sheetContent(o);
    if(!scrim){
      sheetOpener=document.activeElement&&document.activeElement!==document.body?focusSig(document.activeElement)||document.activeElement:null;
      layer.insertAdjacentHTML('beforeend',`<div class="scrim ${RM()?'':'opening'}" data-scrim="1"><div class="sheet" role="dialog" aria-modal="true" aria-labelledby="sheet-title" tabindex="-1"><div class="sheet-head"><h2 id="sheet-title"></h2><button class="icon-btn" data-a="closeOverlay" aria-label="Close">${ic('x','ic-md')}</button></div><div class="sheet-body"></div><div class="sheet-foot"></div></div></div>`);
      scrim=layer.querySelector('.scrim:not(.closing)'); sheetKey=null;
      scrim.addEventListener('animationend',e=>{ if(e.target===scrim) scrim.classList.remove('opening'); });
      document.documentElement.classList.add('locked');
    }
    const sh=scrim.querySelector('.sheet'), bodyEl=scrim.querySelector('.sheet-body');
    sh.classList.toggle('wide',!!c.wide);
    scrim.querySelector('#sheet-title').innerHTML=c.title;
    bodyEl.innerHTML=c.body; scrim.querySelector('.sheet-foot').innerHTML=c.foot||'';
    if(key!==sheetKey){ bodyEl.scrollTop=0; sheetKey=key; requestAnimationFrame(()=>{ if(!sh.contains(document.activeElement)) sh.focus({preventScroll:true}); }); }
  } else if(scrim){ closeSheetDom(scrim); }
  // urgent support: appears immediately, no animation
  let urg=$('#urgent');
  if(S.red&&!urg){
    $('#layer').insertAdjacentHTML('beforeend',`<div class="urgent-screen" id="urgent" role="alertdialog" aria-modal="true" aria-labelledby="urg-h" aria-describedby="urg-d"><div class="urgent-inner"><div class="flow-hero">${ill('heart','lg')}</div><h1 id="urg-h" tabindex="-1">You’re not alone.</h1><p id="urg-d" style="margin:var(--sp-2) 0 var(--sp-6)">These feelings can be a side effect early on. Reach out now.</p>
     <div class="stack"><a class="btn block" href="tel:988">${ic('phone')}Call 988</a><a class="btn block" href="sms:988">${ic('message')}Text 988</a></div><p class="small" style="margin-top:var(--sp-3)">Suicide & Crisis Lifeline · 988lifeline.org</p><p class="small" style="margin-top:var(--sp-2)">In danger now? Call <b>911</b>.</p>
     ${D.circle?`<button class="btn block outline" style="margin-top:var(--sp-5)" data-a="redCircle">${ic('users')}Ask my circle to reach out</button>`:''}
     <button class="btn block outline" data-a="closeRed" style="margin-top:auto;margin-top:max(var(--sp-6),auto)">I’ve reached out · close</button></div></div>`);
    document.documentElement.classList.add('locked'); requestAnimationFrame(()=>{const h=$('#urg-h'); if(h) h.focus({preventScroll:true});});
  } else if(!S.red&&urg){ urg.remove(); if(!S.overlay) document.documentElement.classList.remove('locked'); }
}
function closeSheetDom(scrim){
  const restore=sheetOpener; sheetOpener=null; sheetKey=null;
  const finish=()=>{ scrim.remove(); if(!S.red&&!$('#layer .scrim')) document.documentElement.classList.remove('locked');
    let el=typeof restore==='string'?document.querySelector(restore):restore; if(el&&document.contains(el)) el.focus({preventScroll:true}); };
  if(RM()){ finish(); return; }
  scrim.classList.remove('opening'); scrim.classList.add('closing');
  let done=false; const f=()=>{ if(done) return; done=true; finish(); };
  scrim.addEventListener('animationend',e=>{ if(e.target===scrim) f(); }); setTimeout(f,320);
}
function closeOverlay(){ S.overlay=null; render(); }
function settingsBody(){ const p=D.profile;
  const g=(title,body,extra)=>`<section class="group ${extra||''}"><div class="group-title"><h3>${title}</h3></div>${body}</section>`;
  let h=g('Appearance',`<div class="themes" role="radiogroup" aria-label="Theme">${THEMES.map(t=>`<button class="theme-card" role="radio" aria-checked="${D.theme===t.id}" data-a="theme" data-v="${t.id}"><div class="mini" data-theme="${t.id}" aria-hidden="true"><div class="m-eye">Today</div><div class="m-h">How’s today?</div><span class="m-chip">Wk 2</span><div class="m-card"><span class="m-blob"><i></i></span><span class="m-lines"><i></i><i></i></span><span class="m-btn">Check in</span></div></div><span class="tname">${t.name}<span class="tcheck">${ic('check')}</span></span><span class="tdesc">${t.desc}</span></button>`).join('')}</div>`);
  h+=g('Personal details',`<div class="grid-2" style="grid-template-columns:repeat(auto-fit,minmax(13rem,1fr))"><div class="field"><label class="label" for="set-name">Name</label><input id="set-name" type="text" value="${esc(D.name)}" data-a="nameIn" autocomplete="given-name"></div><div class="field" style="margin-top:0"><label class="label" for="set-phone">Phone <span class="opt-note">(for texts)</span></label><input id="set-phone" type="tel" value="${esc(D.phone)}" data-a="phoneIn" autocomplete="tel"></div></div>`);
  if(isPatient()){
    h+=g('Routine preferences',`<div class="stack-lg"><div class="grid-2"><div class="field"><label class="label" for="set-wake">Up around</label><input id="set-wake" type="time" value="${p.wake}" data-a="prof" data-k="wake"></div><div class="field" style="margin-top:0"><label class="label" for="set-bed">Asleep around</label><input id="set-bed" type="time" value="${p.bed}" data-a="prof" data-k="bed"></div></div>
      <div><p class="label">Meals</p>${mealsEditor()}</div>
      <div><p class="label">Body</p>${bodyEditor(false)}</div>
      <div><p class="label">Feel like me</p>${iconChips('hobby',HOBBIES,D.hobbies,'Add…')}</div></div>`);
    h+=g('Medication',`<div class="btn-row"><button class="btn quiet" data-a="sheet" data-v="plan">${ic('clock')}Review my time</button><button class="btn quiet" data-a="addMed">${ic('pill')}Change medication</button></div>`);
  }
  if(D.role!=='both') h+=g('Roles',`<button class="btn quiet" data-a="makeBoth">${ic('users')}${D.role==='supporter'?'I’m also starting a medication':'I’m also supporting someone'}</button>`);
  if(isPatient()) h+=g('Demo tools',`<div class="row between wrap"><p class="small muted grow" style="min-width:12rem">${D.sample?'Sample check-ins are on. They’re labeled as sample data throughout.':'Fill in two weeks of labeled sample check-ins for a demo.'}</p><button class="btn quiet sm" data-a="sampleData">${ic('flask')}${D.sample?'Remove sample check-ins':'Add 2 weeks of sample check-ins'}</button></div>`);
  h+=`<p class="privacy">${ic('lock')}Everything stays on this device.</p>`;
  h+=g('Reset',`<div class="danger-zone row between wrap"><p class="small grow" style="min-width:12rem">Clear all data on this device and start again.</p><button class="btn danger-quiet sm" data-a="sheet" data-v="reset">${ic('trash')}Start over</button></div>`);
  return `<div class="settings">${h}</div>`; }
function toast(t,icon){
  const r=$('#toast'); clearTimeout(S._tt); clearTimeout(S._tt2);
  r.innerHTML=`<div class="toast ${RM()?'':'in'}" role="status">${ic(icon||'check-circle')}<span>${esc(t)}</span></div>`;
  S._tt=setTimeout(()=>{ const el=r.firstElementChild; if(!el) return; if(RM()){ r.innerHTML=''; return; } el.classList.remove('in'); el.classList.add('out'); S._tt2=setTimeout(()=>{ r.innerHTML=''; },200); },2600);
}

/* ---------- Synapse animation (theme-aware; static under reduced motion) ---------- */
let synRAF=null;
function startSynapse(){
  S.flags.needSyn=false; cancelAnimationFrame(synRAF); const cv=document.getElementById('syn'); if(!cv) return; const g=cv.getContext('2d'), M=MECH[drug().mech];
  const cs=getComputedStyle(document.documentElement), v=n=>cs.getPropertyValue(n).trim();
  const col={cellA:v('--c-cell-a'),cellB:v('--c-cell-b'),label:v('--text-2'),rec:v('--pri'),pump:v('--c-pump'),plug:v('--surface'),font:v('--font-body')||'sans-serif'};
  const chemC=c=>v('--c-'+c);
  const W=680,parts=[];let t=0,sig=0;const pumps=[[150,140],[530,140]],recs=[200,290,390,480];
  const rr=(x,y,w,h,r)=>{g.beginPath();g.moveTo(x+r,y);g.arcTo(x+w,y,x+w,y+h,r);g.arcTo(x+w,y+h,x,y+h,r);g.arcTo(x,y+h,x,y,r);g.arcTo(x,y,x+w,y,r);g.closePath();g.fill();};
  const reduce=RM();
  function step(){ t++; const on=S.flags.syn==='with';
    const boost=M.mode==='boost'&&on; if(t%(boost?3:6)===0) for(let k=0;k<(boost?3:2);k++){const ch=M.chem[Math.floor(Math.random()*M.chem.length)];parts.push({x:230+Math.random()*220,y:125,vx:(Math.random()-.5)*1.6,vy:1.4+Math.random(),life:0,back:false,c:chemC(ch[1])});}
    for(let i=parts.length-1;i>=0;i--){const p=parts[i];p.life++;if(p.life>((on&&M.mode==='block')?170:50)&&!p.back){p.back=true;p.target=pumps[p.x<340?0:1];}
      if(p.back){p.x+=(p.target[0]-p.x)*.08;p.y+=(p.target[1]-p.y)*.08;if(Math.hypot(p.x-p.target[0],p.y-p.target[1])<6){parts.splice(i,1);continue;}}
      else{p.x+=p.vx;p.y+=p.vy;if(p.y>248){p.y=248;p.vy*=-.5;}if(p.y<120)p.vy=Math.abs(p.vy);p.vy+=(Math.random()-.5)*.25;p.vx+=(Math.random()-.5)*.25;p.x=clamp(p.x,90,590);}}
    const near=parts.filter(p=>!p.back&&p.y>205).length;sig+=(near-sig)*.05;
  }
  function draw(){ const on=S.flags.syn==='with'; g.clearRect(0,0,W,360);
    g.fillStyle=col.cellA;g.beginPath();g.moveTo(60,0);g.lineTo(620,0);g.lineTo(620,100);g.quadraticCurveTo(340,160,60,100);g.closePath();g.fill();
    g.fillStyle=col.label;g.font=`600 20px ${col.font}`;g.fillText('Sending cell',80,38);
    g.fillStyle=col.cellB;g.beginPath();g.moveTo(60,360);g.lineTo(620,360);g.lineTo(620,285);g.quadraticCurveTo(340,238,60,285);g.closePath();g.fill();g.fillStyle=col.label;g.fillText('Receiving cell',80,342);
    recs.forEach(x=>{const hit=parts.some(p=>!p.back&&Math.abs(p.x-x)<26&&p.y>240);g.fillStyle=col.rec;g.globalAlpha=hit?1:.45;rr(x-18,256,36,15,7);g.globalAlpha=1;});
    pumps.forEach(([x,y])=>{g.fillStyle=col.pump;rr(x-22,y-20,44,26,8);if(on){g.fillStyle=col.plug;g.fillRect(x-14,y-10,28,6);}});
    parts.forEach(p=>{g.fillStyle=p.c;g.beginPath();g.arc(p.x,p.y,6,0,7);g.fill();});
    const val=clamp(sig/10,0,1),sv=document.getElementById('sigv'),sb=document.getElementById('sigb');if(sv){sv.textContent=val<.35?'Weak':val<.65?'Moderate':'Stronger';sb.style.width=(val*100)+'%';}
  }
  if(reduce){ for(let i=0;i<420;i++) step(); draw(); S._synStatic=true; return; }
  S._synStatic=false;
  (function frame(){ if(!document.getElementById('syn')) return; step(); draw(); synRAF=requestAnimationFrame(frame); })();
}

/* ============================================================
   Actions
   ============================================================ */
document.addEventListener('click',e=>{
  const sc=e.target.closest('[data-scrim]'); if(sc&&e.target===sc){ closeOverlay(); return; }
  const el=e.target.closest('[data-a]'); if(!el) return;
  if(el.disabled||el.getAttribute('aria-disabled')==='true') return;
  const a=el.dataset.a, v=el.dataset.v, p=D.profile;
  switch(a){
   case 'home': e.preventDefault(); if(D.onboarded&&isPatient()){ S.tab='today'; S.ci=null; } render(); return;
   case 'setRole': D.role=v; render(); return;
   case 'obNext': obNext(); return;
   case 'obBack': S.step=Math.max(0,S.step-1); render(); return;
   case 'meals': { const n=clamp(p.meals.length+Number(v),1,6), defs={1:['12:30'],2:['08:00','18:30'],3:['07:30','12:30','18:30'],4:['07:30','12:30','15:30','18:30'],5:['07:30','10:30','12:30','15:30','18:30'],6:['07:30','10:00','12:30','15:00','18:30','21:00']}; p.meals=defs[n].slice(); recheckPlan(); save(); render(); return; }
   case 'pflag': p[el.dataset.k]=!p[el.dataset.k]; recheckPlan(); save(); render(); return;
   case 'addBody': { const t=($('#custom-body').value||'').trim(); if(!t) return; p.custom=p.custom||[]; if(!p.custom.includes(t)) p.custom.push(t); recheckPlan(); save(); render(); return; }
   case 'rmBody': p.custom=(p.custom||[]).filter(x=>x!==v); recheckPlan(); save(); render(); return;
   case 'toggleList': { const arr=el.dataset.k==='hobby'?D.hobbies:D.supportCard; const i=arr.indexOf(v); i>=0?arr.splice(i,1):arr.push(v); save(); render(); return; }
   case 'addCustom': { const t=(document.getElementById('custom-'+el.dataset.k).value||'').trim(); if(!t) return; const arr=el.dataset.k==='hobby'?D.hobbies:D.supportCard; if(!arr.includes(t)) arr.push(t); save(); render(); return; }
   case 'addOther': { const t=($('#otherIn').value||'').trim(); if(!t) return; if(!D.otherMeds.includes(t)) D.otherMeds.push(t); recheckPlan(); save(); render(); return; }
   case 'addOtherV': if(!D.otherMeds.includes(v)) D.otherMeds.push(v); recheckPlan(); save(); render(); return;
   case 'rmOther': D.otherMeds=D.otherMeds.filter(x=>x!==v); recheckPlan(); save(); render(); return;
   case 'src': S.scanSource=v; S.photo=null; S.photoFile=null; S.extractErr=null; if(v==='manual') S.extract=Object.assign({start:todayKey(),source:'manual'},S.extract||{}); render(); return;
   case 'srcReset': S.scanSource=null; S.extract=null; S.extractErr=null; render(); return;
   case 'srcManualFix': S.scanSource='manual'; S.step=obSteps().indexOf('medsource'); render(); return;
   case 'pick': $('#file').click(); return;
   case 'readPhoto': readPhoto(); return;
   case 'manDrug': S.extract=S.extract||{start:todayKey(),source:'manual'}; S.extract.drugId=v; render(); return;
   case 'mgPick': S.extract.mg=Number(v); render(); return;
   case 'syn': S.flags.syn=v; document.querySelectorAll('[data-a=syn]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.v===v))); if(S._synStatic) startSynapse(); return;
   case 'pickPlan': { const o=routineOptions().find(x=>x.id===v); if(o){ D.plan={id:o.id,time:o.time,label:o.label,food:o.meal}; save(); render(); } return; }
   case 'createCircle': createCircle(); return;
   case 'invite': sendToCircle(`Hey! I’m starting a new medication and using DoseWise for the first weeks. Would you be in my corner? Tap to join:`); return;
   case 'tab': S.tab=v; render(); return;
   case 'view': S.view=v; render(); return;
   case 'settings': S.overlay='settings'; renderLayer(); return;
   case 'sheet': S.overlay=v; renderLayer(); return;
   case 'closeOverlay': closeOverlay(); return;
   case 'theme': D.theme=v; save(); render(); return;
   case 'makeBoth': if(D.role==='supporter'){ D.role='both'; D.onboarded=false; S.step=obSteps().indexOf('day'); } else { D.role='both'; toast('Open the invite link a friend texts you.','mail'); } S.overlay=null; save(); render(); return;
   case 'addMed': S.overlay=null; if(D.role==='supporter') D.role='both'; if(!D.role) D.role='patient'; D.onboarded=false; S.scanSource=null; S.extract=null; S.photo=null; S.step=obSteps().indexOf('medsource'); render(); return;
   case 'sampleData': sampleData(); S.overlay=null; render(); return;
   case 'doReset': D=fresh(); S.overlay=null; S.step=0; save(); render(); return;
   case 'startCi': case 'editCi': { const x=D.logs[todayKey()]; S.ci=x?{taken:x.taken,time:x.time||(D.plan?D.plan.time:'08:00'),food:x.food,sick:x.sick,ills:x.ills.slice(),mood:x.mood,sleep:x.sleep,energy:x.energy,fx:x.fx.slice(),noFx:!x.fx.length,hobby:x.hobby||'',connected:x.connected,safety:x.safety,helped:{}}:{taken:null,time:D.plan?D.plan.time:'08:00',food:D.plan?D.plan.food:true,sick:null,ills:[],mood:0,sleep:0,energy:0,fx:[],noFx:false,hobby:null,connected:null,safety:null,helped:{}}; S.ciStep=0; render(); return; }
   case 'ci': { const k=el.dataset.k, c=S.ci; if(['sleep','energy'].includes(k)) c[k]=Number(v); else if(k==='hobby') c.hobby=v; else if(k==='noFx'){c.noFx=!c.noFx;if(c.noFx)c.fx=[];} else c[k]=v==='1'; render(); return; }
   case 'moodPick': S.ci.mood=Number(v); render(); return;
   case 'ciMoodNext': if(!S.ci.mood) return; S.ciStep++; render(); return;
   case 'ciList': { const arr=S.ci[el.dataset.k], i=arr.indexOf(v); i>=0?arr.splice(i,1):arr.push(v); if(el.dataset.k==='fx') S.ci.noFx=false; render(); return; }
   case 'ciHobbyAdd': { const t=($('#ciHobby').value||'').trim(); if(!t) return; S.ci.hobby=t; if(!D.hobbies.includes(t)) D.hobbies.push(t); render(); return; }
   case 'ciHelp': S.ci.helped[el.dataset.id]=v; render(); return;
   case 'ciNext': S.ciStep++; render(); return;
   case 'ciBack': S.ciStep=Math.max(0,S.ciStep-1); render(); return;
   case 'ciClose': S.ci=null; render(); return;
   case 'ciSave': saveCheckin(); return;
   case 'openRed': S.red=true; renderLayer(); return;
   case 'closeRed': S.red=false; renderLayer(); { const b=$('[data-a=openRed]'); if(b) b.focus({preventScroll:true}); } return;
   case 'redCircle': D.circle.red=Date.now(); save(); sendToCircle(`I’m having a really hard time today. Could you reach out?`); return;
   case 'status': D.circle.status={k:v,at:Date.now()}; save(); sendToCircle({rough:'Rough day today. No need to talk, just letting you know.',company:'Could use some company today.',good:'Good day today!'}[v]); render(); return;
   case 'askCustom': case 'askQuick': { const t=a==='askQuick'?v:($('#askIn').value||'').trim(); if(!t||!D.circle) return; D.circle.asks=D.circle.asks||[]; D.circle.asks.push({id:rid(),text:t,at:Date.now(),claimedBy:null}); save(); sendToCircle(`Small ask: ${t}`); render(); return; }
   case 'milestone': sendToCircle(`${Math.floor(dayNum()/7)} weeks done! Thanks for being in my corner.`); return;
   case 'helped': D.helped[el.dataset.id]=v; save(); render(); return;
   case 'preview': S.overlay={kind:'preview',id:v}; renderLayer(); return;
   case 'copy': copyText(v); return;
   case 'copySummary': copyText(summaryText(reportData())+'\n\n'+reportData().script); return;
   case 'print': window.print(); return;
   case 'when': S.flags['when-'+el.dataset.id]=v; render(); return;
   case 'sendMsg': { const t=($('#msg-'+el.dataset.id).value||'').trim(); if(!t) return; const w=S.flags['when-'+el.dataset.id]; const wh=w==='today'?todayKey():w==='tomorrow'?addDays(todayKey(),1):w==='weekend'?addDays(todayKey(),(6-new Date().getDay()+7)%7||0):null; supSend(v,{t:el.dataset.kind==='plan'?'plan':'message',x:t,wh},t); return; }
   case 'think': supSend(v,{t:'think'},'Thinking of you. No need to reply.'); return;
   case 'claim': { const sup=D.supporting.find(s=>s.code===v), ask=(sup.snap.ak||[]).find(x=>x.id===el.dataset.id); sup.snap.ak=(sup.snap.ak||[]).filter(x=>x.id!==el.dataset.id); save(); supSend(v,{t:'claim',ak:el.dataset.id,x:ask?ask.text:''},`I’ve got it: ${ask?ask.text:''}`); render(); return; }
   case 'pause': { const sup=D.supporting.find(s=>s.code===v); sup.me.pausedUntil=addDays(todayKey(),7); save(); supSend(v,{t:'pause',pu:sup.me.pausedUntil},'Taking a short break this week. Still here if it’s urgent.'); render(); return; }
   case 'unpause': { const sup=D.supporting.find(s=>s.code===v); sup.me.pausedUntil=null; save(); supSend(v,{t:'pause',pu:null},'I’m back.'); render(); return; }
   case 'capSheet': S.overlay={kind:'cap',code:v}; renderLayer(); return;
   case 'capSet': { const sup=D.supporting.find(s=>s.code===el.dataset.c); sup.me.cap=v; save(); renderLayer(); return; }
   case 'supCode': S.flags.supCode=v; render(); return;
   case 'jrel': S.joinDraft.rel=v; render(); return;
   case 'jcap': S.joinDraft.cap=v; render(); return;
   case 'jtask': { const t=S.joinDraft.tasks, i=t.indexOf(v); i>=0?t.splice(i,1):t.push(v); render(); return; }
   case 'joinBack': if(S.joinDraft.step) S.joinDraft.step--; else S.joinDraft=null; render(); return;
   case 'joinNext': { const j=S.joinDraft; if(j.step===0&&!D.name){ toast('Add your name first','user'); const n=$('#j-name'); if(n) n.focus(); return; } if(j.step<3){ j.step++; render(); return; }
     const s=j.snap; D.supporting=D.supporting.filter(x=>x.code!==s.c); D.supporting.push({code:s.c,snap:s,me:{id:D.myId,name:D.name,rel:j.rel,cap:j.cap,tasks:j.tasks,pausedUntil:null}});
     if(!D.role) D.role='supporter'; else if(D.role==='patient') D.role='both'; D.onboarded=true; S.joinDraft=null; S.view='support'; S.flags.supCode=s.c; save(); render();
     supSend(s.c,{t:'join',r:j.rel,cp:j.cap,tk:j.tasks,ph:D.phone},`I’m in your corner. Tap to add me to your circle:`); return; }
  }
});
function copyText(t){ try{navigator.clipboard.writeText(t).then(()=>toast('Copied','copy'),()=>toast('Select and copy the text','info'));}catch(e){toast('Select and copy the text','info');} }
document.addEventListener('input',e=>{ const el=e.target,a=el.dataset&&el.dataset.a;
  if(a==='nameIn'){D.name=el.value.slice(0,40);save();}
  if(a==='phoneIn'){D.phone=el.value.replace(/[^\d+]/g,'').slice(0,16);save();}
  if(a==='exField'&&S.extract) S.extract[el.dataset.k]=el.value;
  if(a==='mgIn'){ S.extract=S.extract||{}; S.extract.mg=parseFloat(el.value)||null; const b=document.querySelector('.btn[data-a=obNext]'); if(b) b.disabled=!(S.extract.drugId&&S.extract.mg>0); }
  if(a==='qtyIn'){ S.extract.quantity=String(parseInt(el.value,10)||''); }
});
document.addEventListener('change',e=>{ const el=e.target,a=el.dataset&&el.dataset.a;
  if(el.id==='file'&&el.files&&el.files[0]){ S.photoFile=el.files[0]; S.extractErr=null; const fr=new FileReader(); fr.onload=()=>{S.photo=fr.result;render();}; fr.readAsDataURL(S.photoFile); el.value=''; return; }
  if(a==='prof'){ D.profile[el.dataset.k]=el.value; recheckPlan(); save(); render(); }
  if(a==='mealTime'){ D.profile.meals[Number(el.dataset.i)]=el.value; D.profile.meals.sort(); recheckPlan(); save(); render(); }
  if(a==='ciTime'){ S.ci.time=el.value; render(); }
  if(a==='mgIn'){ render(); }
});
document.addEventListener('keydown',e=>{
  if(e.key==='Enter'&&e.target.tagName==='INPUT'){ const b=e.target.closest('.inline-add')&&e.target.closest('.inline-add').querySelector('button[data-a]'); if(b){e.preventDefault();b.click();return;} }
  // radiogroups: arrow keys move selection (mood picker, themes, options)
  const r=e.target.closest&&e.target.closest('[role=radio]');
  if(r&&['ArrowRight','ArrowDown','ArrowLeft','ArrowUp'].includes(e.key)){ const grp=r.closest('[role=radiogroup]'); if(grp){ const items=[...grp.querySelectorAll('[role=radio]')], i=items.indexOf(r), n=items[(i+(e.key==='ArrowRight'||e.key==='ArrowDown'?1:-1)+items.length)%items.length]; e.preventDefault(); const sig=focusSig(n); n.click(); requestAnimationFrame(()=>{ const m=sig&&document.querySelector(sig); if(m) m.focus(); }); return; } }
  if(e.key==='Escape'){ if(S.red) return; if(S.overlay){ e.preventDefault(); closeOverlay(); } return; }
  if(e.key==='Tab'){ // keep focus inside an open dialog
    const box=S.red?$('#urgent'):S.overlay?$('#layer .scrim:not(.closing) .sheet'):null; if(!box) return;
    const f=[...box.querySelectorAll('button:not([disabled]),a[href],input,textarea,select,[tabindex]:not([tabindex="-1"])')].filter(x=>x.offsetParent!==null); if(!f.length) return;
    const first=f[0], last=f[f.length-1];
    if(e.shiftKey&&(document.activeElement===first||!box.contains(document.activeElement))){ e.preventDefault(); last.focus(); }
    else if(!e.shiftKey&&(document.activeElement===last||!box.contains(document.activeElement))){ e.preventDefault(); first.focus(); }
  }
});
// on-screen keyboard: tuck the bottom nav away while typing on phones
document.addEventListener('focusin',e=>{ if(e.target.matches&&e.target.matches('input:not([type=time]):not([type=date]),textarea')) $('#app').classList.add('kbd'); });
document.addEventListener('focusout',()=>{ setTimeout(()=>{ const a=document.activeElement; if(!(a&&a.matches&&a.matches('input,textarea'))) $('#app').classList.remove('kbd'); },50); });
window.addEventListener('scroll',()=>{ const t=$('#topbar'); if(t) t.classList.toggle('scrolled',window.scrollY>4); },{passive:true});
window.addEventListener('hashchange',()=>{handleHash();render();});
if(window.matchMedia){ const mq=matchMedia('(prefers-reduced-motion: reduce)'); const h=()=>{ if(document.getElementById('syn')) startSynapse(); }; mq.addEventListener?mq.addEventListener('change',h):mq.addListener(h); }
document.body.insertAdjacentHTML('afterbegin',spriteSVG());
handleHash(); render();
if('serviceWorker' in navigator&&(location.protocol==='https:'||location.hostname==='localhost')) navigator.serviceWorker.register('sw.js').catch(()=>{});
